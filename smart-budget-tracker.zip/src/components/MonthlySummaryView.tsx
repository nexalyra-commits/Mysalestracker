import React, { useState } from 'react';
import { Expense, ExpenseCategory, CategoryBudgets, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  BarChart,
  Bar
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  PieChart as PieChartIcon,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Sparkles
} from 'lucide-react';

interface MonthlySummaryViewProps {
  salary: number;
  expenses: Expense[];
  categoryBudgets: CategoryBudgets;
  savingsGoal: number;
  currency: Currency;
  onNavigate: (tab: any) => void;
}

export const MonthlySummaryView: React.FC<MonthlySummaryViewProps> = ({
  salary,
  expenses,
  categoryBudgets,
  savingsGoal,
  currency,
  onNavigate,
}) => {
  const [viewType, setViewType] = useState<'total' | 'category'>('total');

  // Compute current month expenses total
  const currentMonthTotal = expenses.reduce((sum, e) => sum + e.amount, 0);

  // Compute category totals for current month
  const categoryTotals: Record<ExpenseCategory, number> = {
    groceries: 0,
    household: 0,
    personal: 0,
    transport: 0,
    dining: 0,
    other: 0,
  };

  expenses.forEach((e) => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
  });

  // Construct 6-month historical data (March - August 2026)
  const sixMonthsData = [
    {
      month: 'Mar 2026',
      totalSpent: 2120.5,
      groceries: 520,
      household: 1250,
      dining: 180,
      transport: 110,
      personal: 60.5,
      other: 0,
      savings: salary - 2120.5,
    },
    {
      month: 'Apr 2026',
      totalSpent: 2380.0,
      groceries: 580,
      household: 1350,
      dining: 210,
      transport: 140,
      personal: 80,
      other: 20,
      savings: salary - 2380.0,
    },
    {
      month: 'May 2026',
      totalSpent: 1950.25,
      groceries: 490,
      household: 1250,
      dining: 120,
      transport: 60.25,
      personal: 30,
      other: 0,
      savings: salary - 1950.25,
    },
    {
      month: 'Jun 2026',
      totalSpent: 2410.8,
      groceries: 610,
      household: 1380,
      dining: 220,
      transport: 120.8,
      personal: 80,
      other: 0,
      savings: salary - 2410.8,
    },
    {
      month: 'Jul 2026',
      totalSpent: 2180.4,
      groceries: 540,
      household: 1300,
      dining: 190,
      transport: 90.4,
      personal: 60,
      other: 0,
      savings: salary - 2180.4,
    },
    {
      month: 'Aug 2026 (Current)',
      totalSpent: Math.round(currentMonthTotal * 100) / 100,
      groceries: Math.round(categoryTotals.groceries * 100) / 100,
      household: Math.round(categoryTotals.household * 100) / 100,
      dining: Math.round(categoryTotals.dining * 100) / 100,
      transport: Math.round(categoryTotals.transport * 100) / 100,
      personal: Math.round(categoryTotals.personal * 100) / 100,
      other: Math.round(categoryTotals.other * 100) / 100,
      savings: Math.round((salary - currentMonthTotal) * 100) / 100,
    },
  ];

  const totalSixMonthSpend = sixMonthsData.reduce((acc, item) => acc + item.totalSpent, 0);
  const avgSixMonthSpend = Math.round(totalSixMonthSpend / 6);
  const highestSpendMonth = [...sixMonthsData].sort((a, b) => b.totalSpent - a.totalSpent)[0];
  const lowestSpendMonth = [...sixMonthsData].sort((a, b) => a.totalSpent - b.totalSpent)[0];

  const currentMonthSaved = Math.max(0, salary - currentMonthTotal);
  const goalProgressPct = savingsGoal > 0 ? Math.min(100, Math.round((currentMonthSaved / savingsGoal) * 100)) : 0;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-[#1D2640] via-[#243152] to-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-3 py-1 rounded-full bg-[#9D9E54]/20 border border-[#9D9E54]/40 text-[#9D9E54] text-[10px] font-bold uppercase tracking-widest">
              Financial Intelligence
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            6-Month Monthly Spending Trends
          </h2>
          <p className="text-xs text-[#A0AEC0] mt-1">
            Track total monthly expenditures, category breakdowns, and net savings progress over time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#13192B] border border-[#2B395B] rounded-2xl px-4 py-2 text-right">
            <div className="text-[10px] text-[#A0AEC0] uppercase font-semibold">6-Mo Average Spend</div>
            <div className="text-lg font-bold text-[#9D9E54] font-mono">{formatCurrency(avgSixMonthSpend, currency, 0)} / mo</div>
          </div>
        </div>
      </div>

      {/* 6-Month Trend Line Chart Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-[#2B395B] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Spending Progression (Past 6 Months)</h3>
              <p className="text-xs text-[#A0AEC0]">Comparing monthly totals and category distribution</p>
            </div>
          </div>

          <div className="flex items-center bg-[#13192B] border border-[#2B395B] rounded-2xl p-1 gap-1 self-start sm:self-auto">
            <button
              onClick={() => setViewType('total')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                viewType === 'total'
                  ? 'bg-[#9D9E54] text-[#13192B] shadow-md'
                  : 'text-[#A0AEC0] hover:text-white'
              }`}
            >
              Total Spend
            </button>
            <button
              onClick={() => setViewType('category')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                viewType === 'category'
                  ? 'bg-[#9D9E54] text-[#13192B] shadow-md'
                  : 'text-[#A0AEC0] hover:text-white'
              }`}
            >
              By Category
            </button>
          </div>
        </div>

        {/* Recharts Line Chart */}
        <div className="h-[340px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sixMonthsData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#253352" vertical={false} />
              <XAxis dataKey="month" stroke="#8A99AD" tick={{ fill: '#8A99AD', fontSize: 11 }} />
              <YAxis
                stroke="#8A99AD"
                tick={{ fill: '#8A99AD', fontSize: 11 }}
                tickFormatter={(val) => `${currency.symbol}${val}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#13192B',
                  borderColor: '#2B395B',
                  borderRadius: '16px',
                  color: '#fff',
                  fontSize: '12px',
                  boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)',
                }}
                formatter={(val: any) => [formatCurrency(Number(val), currency), '']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />

              {viewType === 'total' ? (
                <>
                  <Line
                    type="monotone"
                    dataKey="totalSpent"
                    name="Total Monthly Spent"
                    stroke="#9D9E54"
                    strokeWidth={3.5}
                    dot={{ fill: '#9D9E54', r: 5 }}
                    activeDot={{ r: 8, stroke: '#fff', strokeWidth: 2 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="savings"
                    name="Monthly Surplus / Saved"
                    stroke="#38bdf8"
                    strokeWidth={2.5}
                    strokeDasharray="4 4"
                    dot={{ fill: '#38bdf8', r: 4 }}
                  />
                </>
              ) : (
                <>
                  <Line type="monotone" dataKey="groceries" name="Groceries" stroke="#9D9E54" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="household" name="Household" stroke="#818cf8" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="dining" name="Dining" stroke="#f59e0b" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="transport" name="Transport" stroke="#38bdf8" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="personal" name="Personal" stroke="#f43f5e" strokeWidth={2.5} />
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid of Key Analytical Insights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Monthly Average comparison */}
        <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#A0AEC0] font-semibold uppercase tracking-wider">
            <span>Current vs. 6-Mo Avg</span>
            <Calendar className="w-4 h-4 text-[#9D9E54]" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {formatCurrency(currentMonthTotal, currency)}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs">
              {currentMonthTotal <= avgSixMonthSpend ? (
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <TrendingDown className="w-3.5 h-3.5" />
                  {Math.abs(Math.round(((currentMonthTotal - avgSixMonthSpend) / avgSixMonthSpend) * 100))}% below 6-mo avg
                </span>
              ) : (
                <span className="text-rose-400 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  {Math.round(((currentMonthTotal - avgSixMonthSpend) / avgSixMonthSpend) * 100)}% above 6-mo avg
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Metric 2: Peak Spend Month */}
        <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#A0AEC0] font-semibold uppercase tracking-wider">
            <span>Highest Spend Month</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {formatCurrency(highestSpendMonth?.totalSpent || 0, currency)}
            </div>
            <p className="text-xs text-[#A0AEC0] mt-1">
              Recorded in <strong className="text-white">{highestSpendMonth?.month}</strong>
            </p>
          </div>
        </div>

        {/* Metric 3: Savings Target Progress */}
        <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#A0AEC0] font-semibold uppercase tracking-wider">
            <span>Savings Target Status</span>
            <Sparkles className="w-4 h-4 text-[#9D9E54]" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {formatCurrency(currentMonthSaved, currency)} / {formatCurrency(savingsGoal, currency, 0)}
            </div>
            <div className="w-full bg-[#13192B] rounded-full h-2 mt-2 border border-[#253352] overflow-hidden">
              <div
                className="bg-[#9D9E54] h-full rounded-full transition-all duration-500"
                style={{ width: `${goalProgressPct}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
