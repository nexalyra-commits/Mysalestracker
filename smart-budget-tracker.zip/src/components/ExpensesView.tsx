import React, { useState } from 'react';
import { Expense, ExpenseCategory, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import {
  Plus,
  Trash2,
  Search,
  Download,
  Filter,
  DollarSign,
  Tag,
  Calendar,
  Store,
  ShoppingCart,
  Home,
  Utensils,
  Car,
  User,
  Package,
  Repeat,
  RotateCcw,
  LayoutGrid,
  List,
  X,
  Sparkles,
  Clock,
  CheckCircle2
} from 'lucide-react';

interface ExpensesViewProps {
  expenses: Expense[];
  currency: Currency;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
}

const CATEGORIES: { id: ExpenseCategory; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'groceries', label: 'Groceries', icon: <ShoppingCart className="w-5 h-5 text-[#9D9E54]" />, color: 'border-[#9D9E54]/30 bg-[#9D9E54]/10 text-[#9D9E54]' },
  { id: 'household', label: 'Household', icon: <Home className="w-5 h-5 text-indigo-400" />, color: 'border-indigo-500/30 bg-indigo-500/10 text-indigo-400' },
  { id: 'personal', label: 'Personal', icon: <User className="w-5 h-5 text-rose-400" />, color: 'border-rose-500/30 bg-rose-500/10 text-rose-400' },
  { id: 'transport', label: 'Transport', icon: <Car className="w-5 h-5 text-sky-400" />, color: 'border-sky-500/30 bg-sky-500/10 text-sky-400' },
  { id: 'dining', label: 'Dining', icon: <Utensils className="w-5 h-5 text-amber-400" />, color: 'border-amber-500/30 bg-amber-500/10 text-amber-400' },
  { id: 'other', label: 'Other', icon: <Package className="w-5 h-5 text-slate-300" />, color: 'border-slate-500/30 bg-slate-500/10 text-slate-300' },
];

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  currency,
  onAddExpense,
  onDeleteExpense,
}) => {
  // Expense Form State
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('groceries');
  const [store, setStore] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringDay, setRecurringDay] = useState(1);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Category View Toggle Mode (List vs Visual Icon Grid)
  const [categoryDisplayMode, setCategoryDisplayMode] = useState<'list' | 'grid'>('list');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!name.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;

    onAddExpense({
      name: name.trim(),
      amount: parsedAmount,
      category,
      store: store.trim() || undefined,
      date: date || new Date().toISOString().slice(0, 10),
      isRecurring,
      recurringDay: isRecurring ? Math.min(31, Math.max(1, recurringDay)) : undefined,
    });

    setName('');
    setAmount('');
    setStore('');
    setIsRecurring(false);
  };

  // Comprehensive Search filtering matching Name, Category, or Store
  const filteredExpenses = expenses.filter((e) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      e.name.toLowerCase().includes(q) ||
      e.category.toLowerCase().includes(q) ||
      (e.store && e.store.toLowerCase().includes(q)) ||
      (e.note && e.note.toLowerCase().includes(q));

    const matchesCategory = selectedCategory === 'all' || e.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredTotal = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Filter recurring expenses
  const recurringExpenses = expenses.filter((e) => e.isRecurring);

  const exportCSV = () => {
    const headers = ['ID', 'Name', 'Amount', 'Category', 'Store', 'Date', 'Is Recurring', 'Repeat Day'];
    const rows = filteredExpenses.map((e) => [
      e.id,
      `"${e.name.replace(/"/g, '""')}"`,
      e.amount.toFixed(2),
      e.category,
      `"${(e.store || '').replace(/"/g, '""')}"`,
      e.date,
      e.isRecurring ? 'Yes' : 'No',
      e.recurringDay || '',
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `expenses-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Log New Expense Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
          <h2 className="font-bold text-white text-sm tracking-tight flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <Plus className="w-4 h-4 stroke-[3]" />
            </div>
            <span>Log New Expense</span>
          </h2>

          <div className="flex items-center gap-2 text-xs text-[#A0AEC0]">
            <Clock className="w-3.5 h-3.5 text-[#9D9E54]" />
            <span>Instant Logging & Recurring Auto-Repeat</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
            {/* Description */}
            <div className="lg:col-span-1 space-y-1">
              <label className="text-[11px] font-semibold text-[#A0AEC0]">Description</label>
              <input
                type="text"
                placeholder="e.g. Organic Milk & Eggs, Rent"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54]"
                required
              />
            </div>

            {/* Amount */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-[#A0AEC0]">Amount ({currency.symbol})</label>
              <div className="relative">
                <span className="text-slate-400 absolute left-3 top-2.5 text-xs font-mono">{currency.symbol}</span>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl pl-8 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54] font-mono"
                  required
                />
              </div>
            </div>

            {/* Category */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-[#A0AEC0]">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#9D9E54] capitalize"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Store / Location */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-[#A0AEC0]">Store / Merchant</label>
              <input
                type="text"
                placeholder="e.g. Aldi, Walmart"
                value={store}
                onChange={(e) => setStore(e.target.value)}
                className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54]"
              />
            </div>

            {/* Submit Button */}
            <div className="space-y-1 flex flex-col justify-end">
              <button
                type="submit"
                className="w-full bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs rounded-2xl py-2 px-4 shadow-md transition-all flex items-center justify-center gap-1.5 active:scale-95"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Add Expense</span>
              </button>
            </div>
          </div>

          {/* Recurring Expense Tag Option */}
          <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-[#2B395B]/50 text-xs">
            <label className="flex items-center gap-2 cursor-pointer text-white font-medium select-none">
              <input
                type="checkbox"
                checked={isRecurring}
                onChange={(e) => setIsRecurring(e.target.checked)}
                className="w-4 h-4 rounded border-[#2B395B] bg-[#13192B] text-[#9D9E54] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#9D9E54]"
              />
              <span className="flex items-center gap-1.5">
                <Repeat className="w-3.5 h-3.5 text-[#9D9E54]" />
                <span>Set as Recurring Expense (repeats monthly)</span>
              </span>
            </label>

            {isRecurring && (
              <div className="flex items-center gap-2 animate-fadeIn">
                <span className="text-[#A0AEC0] text-[11px]">Repeat on day of month:</span>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={recurringDay}
                  onChange={(e) => setRecurringDay(parseInt(e.target.value) || 1)}
                  className="w-16 bg-[#13192B] border border-[#2B395B] rounded-xl px-2 py-1 text-xs text-white text-center font-mono focus:outline-none focus:border-[#9D9E54]"
                />
                <span className="text-[11px] text-[#9D9E54] font-mono">
                  (e.g., Day {recurringDay} of every month)
                </span>
              </div>
            )}
          </div>
        </form>
      </div>

      {/* Category Navigation & View Mode Switcher (List View vs Icon Grid View) */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#2B395B] pb-3">
          <div>
            <h3 className="font-bold text-white text-sm">Expense Category Overview</h3>
            <p className="text-[11px] text-[#A0AEC0]">Toggle between List View and Visual Icon-based Grid View</p>
          </div>

          {/* List vs Grid Toggle Button */}
          <div className="flex items-center bg-[#13192B] border border-[#2B395B] rounded-2xl p-1 gap-1">
            <button
              onClick={() => setCategoryDisplayMode('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                categoryDisplayMode === 'list'
                  ? 'bg-[#9D9E54] text-[#13192B] shadow-md'
                  : 'text-[#A0AEC0] hover:text-white'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List View</span>
            </button>
            <button
              onClick={() => setCategoryDisplayMode('grid')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                categoryDisplayMode === 'grid'
                  ? 'bg-[#9D9E54] text-[#13192B] shadow-md'
                  : 'text-[#A0AEC0] hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Icon Grid View</span>
            </button>
          </div>
        </div>

        {/* Render Categories in Selected Display Mode */}
        {categoryDisplayMode === 'grid' ? (
          /* Visual Icon-Based Grid View */
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-1">
            {CATEGORIES.map((cat) => {
              const catExpenses = expenses.filter((e) => e.category === cat.id);
              const catTotal = catExpenses.reduce((sum, e) => sum + e.amount, 0);
              const isSelected = selectedCategory === cat.id;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'all' : cat.id)}
                  className={`p-4 rounded-2xl border transition-all text-left flex flex-col justify-between space-y-3 cursor-pointer ${
                    isSelected
                      ? 'bg-[#9D9E54]/20 border-[#9D9E54] shadow-lg scale-[1.02]'
                      : 'bg-[#13192B] border-[#2B395B] hover:border-[#3B4D7A]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 rounded-xl bg-[#1D2640] border border-[#2B395B]">
                      {cat.icon}
                    </div>
                    <span className="text-[10px] font-mono text-[#A0AEC0] bg-[#1D2640] px-2 py-0.5 rounded-full border border-[#2B395B]">
                      {catExpenses.length} items
                    </span>
                  </div>

                  <div>
                    <div className="text-xs font-bold text-white capitalize">{cat.label}</div>
                    <div className="text-sm font-extrabold text-[#9D9E54] font-mono mt-0.5">
                      {formatCurrency(catTotal, currency)}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          /* List View for Categories */
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border ${
                selectedCategory === 'all'
                  ? 'bg-[#9D9E54] text-[#13192B] border-[#9D9E54]'
                  : 'bg-[#13192B] text-[#A0AEC0] border-[#2B395B] hover:text-white'
              }`}
            >
              All Categories ({expenses.length})
            </button>
            {CATEGORIES.map((cat) => {
              const catCount = expenses.filter((e) => e.category === cat.id).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap capitalize transition-all border ${
                    selectedCategory === cat.id
                      ? 'bg-[#9D9E54] text-[#13192B] border-[#9D9E54] font-bold'
                      : 'bg-[#13192B] text-[#A0AEC0] border-[#2B395B] hover:text-white'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className="px-1.5 py-0.5 rounded-full bg-[#1D2640] text-[10px] font-mono">
                    {catCount}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Recurring Subscriptions & Fixed Bills Section */}
      {recurringExpenses.length > 0 && (
        <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-[#2B395B] pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-[#9D9E54]/20 text-[#9D9E54]">
                <Repeat className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                  Recurring Monthly Bills & Subscriptions
                </h3>
                <p className="text-[11px] text-[#A0AEC0]">Auto-repeats every month on designated dates</p>
              </div>
            </div>

            <span className="text-xs font-mono font-bold text-[#9D9E54] bg-[#13192B] px-3 py-1 rounded-full border border-[#2B395B]">
              {formatCurrency(recurringExpenses.reduce((s, r) => s + r.amount, 0), currency)} / mo
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
            {recurringExpenses.map((re) => (
              <div key={re.id} className="p-3.5 rounded-2xl bg-[#13192B] border border-[#2B395B] flex items-center justify-between">
                <div className="space-y-1">
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>{re.name}</span>
                    <span className="px-1.5 py-0.5 rounded-full bg-[#9D9E54]/20 text-[#9D9E54] text-[9px] font-extrabold uppercase">
                      Day {re.recurringDay || 1}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#A0AEC0] capitalize">{re.category} {re.store ? `· ${re.store}` : ''}</div>
                </div>

                <div className="text-right font-mono text-xs font-bold text-white">
                  {formatCurrency(re.amount, currency)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Feed Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-[#2B395B] pb-4">
          {/* Enhanced Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              placeholder="Search expenses by name, category (e.g. dining), or store..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#13192B] border border-[#2B395B] rounded-full pl-9 pr-9 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportCSV}
              className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-full bg-[#13192B] hover:bg-[#253352] border border-[#2B395B] text-xs text-white font-semibold transition-colors shrink-0"
              title="Export filtered expenses to CSV"
            >
              <Download className="w-3.5 h-3.5 text-[#9D9E54]" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        {/* Expenses Feed */}
        <div className="divide-y divide-[#2B395B]/60">
          {filteredExpenses.length === 0 ? (
            <div className="text-center py-12 text-[#A0AEC0] space-y-1">
              <p className="text-xs font-semibold text-white">No expenses match your search filter.</p>
              <p className="text-[11px]">Try searching by name (e.g. 'Coffee'), category (e.g. 'groceries'), or store (e.g. 'Aldi').</p>
            </div>
          ) : (
            filteredExpenses
              .slice()
              .reverse()
              .map((e) => (
                <div
                  key={e.id}
                  className="py-3 flex items-center justify-between group hover:bg-[#161E33] px-3 rounded-2xl transition-colors"
                >
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <span>{e.name}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-[#13192B] border border-[#2B395B] text-[#9D9E54]">
                        {e.category}
                      </span>
                      {e.isRecurring && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-[#9D9E54]/20 border border-[#9D9E54]/40 text-[#9D9E54] flex items-center gap-1">
                          <Repeat className="w-3 h-3" /> Day {e.recurringDay || 1}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-[#A0AEC0]">
                      {e.store && (
                        <span className="flex items-center gap-1">
                          <Store className="w-3 h-3 text-slate-400" />
                          <span>{e.store}</span>
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span className="font-mono">{e.date}</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold text-white font-mono">
                      {formatCurrency(e.amount, currency)}
                    </span>
                    <button
                      onClick={() => onDeleteExpense(e.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                      title="Delete expense"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
          )}
        </div>

        {/* Footer Summary */}
        <div className="pt-3 border-t border-[#2B395B] flex items-center justify-between text-xs text-[#A0AEC0] font-medium">
          <span>
            Showing {filteredExpenses.length} of {expenses.length} expense{expenses.length !== 1 ? 's' : ''}
          </span>
          <span className="font-mono text-white font-bold">
            Filtered Total: {formatCurrency(filteredTotal, currency)}
          </span>
        </div>
      </div>
    </div>
  );
};
