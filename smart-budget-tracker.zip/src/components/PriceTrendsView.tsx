import React, { useState } from 'react';
import { StoreHistory, PriceRecord, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import { STORE_COLORS } from '../data/initialData';
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Calendar,
  Sparkles
} from 'lucide-react';

interface PriceTrendsViewProps {
  storeHistory: StoreHistory;
  currency: Currency;
}

export const PriceTrendsView: React.FC<PriceTrendsViewProps> = ({ storeHistory, currency }) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Extract alerts (hikes & drops)
  const priceHikes: { item: string; store: string; oldP: number; newP: number; pct: number }[] = [];
  const priceDrops: { item: string; store: string; oldP: number; newP: number; pct: number }[] = [];

  Object.entries(storeHistory).forEach(([item, stores]) => {
    Object.entries(stores).forEach(([store, records]) => {
      if (records.length >= 2) {
        const first = records[0].price;
        const latest = records[records.length - 1].price;
        if (first > 0) {
          const pct = ((latest - first) / first) * 100;
          if (pct >= 4) {
            priceHikes.push({
              item,
              store,
              oldP: first,
              newP: latest,
              pct: Math.round(pct * 10) / 10,
            });
          } else if (pct <= -4) {
            priceDrops.push({
              item,
              store,
              oldP: first,
              newP: latest,
              pct: Math.round(Math.abs(pct) * 10) / 10,
            });
          }
        }
      }
    });
  });

  const filteredItems = Object.keys(storeHistory).filter((it) =>
    it.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Alert Banners Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Price Hikes */}
        <div className="bg-[#1D2640] border border-amber-500/40 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2.5 text-amber-400 font-bold text-xs uppercase tracking-wider">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <AlertTriangle className="w-4 h-4 stroke-[2.5]" />
            </div>
            <span>Price Hike / Inflation Alerts ({priceHikes.length})</span>
          </div>

          <div className="divide-y divide-[#2B395B]/80">
            {priceHikes.length === 0 ? (
              <p className="text-xs text-[#A0AEC0] py-3">No significant price increases detected.</p>
            ) : (
              priceHikes.map((hike, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">{hike.item}</span>
                    <div className="text-[11px] text-[#A0AEC0]">{hike.store}</div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center gap-1 font-mono text-amber-400 font-bold">
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>+{hike.pct}%</span>
                    </div>
                    <div className="text-[10px] text-[#A0AEC0] font-mono">
                      {formatCurrency(hike.oldP, currency)} → {formatCurrency(hike.newP, currency)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Price Drops */}
        <div className="bg-[#1D2640] border border-[#9D9E54]/40 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2.5 text-[#9D9E54] font-bold text-xs uppercase tracking-wider">
            <div className="p-2 rounded-xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <Sparkles className="w-4 h-4 stroke-[2.5]" />
            </div>
            <span>Price Drop / Deal Alerts ({priceDrops.length})</span>
          </div>

          <div className="divide-y divide-[#2B395B]/80">
            {priceDrops.length === 0 ? (
              <p className="text-xs text-[#A0AEC0] py-3">No recent price drops recorded.</p>
            ) : (
              priceDrops.map((drop, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">{drop.item}</span>
                    <div className="text-[11px] text-[#A0AEC0]">{drop.store}</div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center gap-1 font-mono text-[#9D9E54] font-bold">
                      <ArrowDownRight className="w-3.5 h-3.5" />
                      <span>-{drop.pct}%</span>
                    </div>
                    <div className="text-[10px] text-[#A0AEC0] font-mono">
                      ${drop.oldP.toFixed(2)} → ${drop.newP.toFixed(2)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Item Timeline & Sparkline Charts Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-[#2B395B] pb-4">
          <h2 className="font-bold text-white text-sm tracking-tight">
            Historical Price Trajectories
          </h2>
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#13192B] border border-[#2B395B] rounded-full pl-9 pr-3.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
            />
          </div>
        </div>

        <div className="space-y-6 divide-y divide-[#2B395B]/60">
          {filteredItems.map((item) => {
            const storesMap = storeHistory[item];

            return (
              <div key={item} className="pt-4 first:pt-0 space-y-3">
                <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                  {item}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(storesMap as Record<string, PriceRecord[]>).map(([store, records]) => {
                    const first = records[0].price;
                    const latest = records[records.length - 1].price;
                    const diff = latest - first;
                    const pct = first > 0 ? (diff / first) * 100 : 0;
                    const storeColor = STORE_COLORS[store] || '#9D9E54';

                    const maxP = Math.max(...records.map((r) => r.price));
                    const minP = Math.min(...records.map((r) => r.price));
                    const range = maxP - minP || 1;

                    return (
                      <div
                        key={store}
                        className="bg-[#13192B] border border-[#2B395B] rounded-2xl p-4 flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full"
                              style={{ backgroundColor: storeColor }}
                            />
                            <span className="font-bold text-xs text-white">
                              {store}
                            </span>
                          </div>

                          <div className="flex items-baseline gap-2 font-mono">
                            <span className="text-base font-bold text-white">
                              {formatCurrency(latest, currency)}
                            </span>
                            <span
                              className={`text-xs font-bold ${
                                pct > 0
                                  ? 'text-amber-400'
                                  : pct < 0
                                  ? 'text-[#9D9E54]'
                                  : 'text-[#A0AEC0]'
                              }`}
                            >
                              {pct > 0 ? `+${pct.toFixed(1)}%` : pct < 0 ? `${pct.toFixed(1)}%` : '0%'}
                            </span>
                          </div>

                          <div className="text-[10px] text-[#A0AEC0]">
                            {records.length} purchase{records.length !== 1 ? 's' : ''} logged
                          </div>
                        </div>

                        {/* Mini Sparkline Bar Chart */}
                        <div className="flex items-end gap-1.5 h-10 px-2 py-1 bg-[#1D2640] rounded-xl border border-[#2B395B]">
                          {records.map((rec, rIdx) => {
                            const barHeight = Math.max(
                              20,
                              ((rec.price - minP) / range) * 100
                            );
                            return (
                              <div
                                key={rIdx}
                                className="w-2.5 rounded-t transition-all group relative"
                                style={{
                                  height: `${barHeight}%`,
                                  backgroundColor: storeColor,
                                }}
                              >
                                <div className="hidden group-hover:block absolute bottom-full mb-1 left-1/2 -translate-x-1/2 px-2 py-1 rounded-lg bg-[#13192B] border border-[#2B395B] text-[10px] font-mono text-white whitespace-nowrap z-10 shadow-md">
                                  {rec.date}: {formatCurrency(rec.price, currency)}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
