import React, { useState } from 'react';
import { Currency } from '../types';
import { CURRENCIES } from '../data/currencies';
import { Globe, X, Check, DollarSign, Plus } from 'lucide-react';

interface CurrencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCurrency: Currency;
  onSelectCurrency: (currency: Currency) => void;
}

export const CurrencyModal: React.FC<CurrencyModalProps> = ({
  isOpen,
  onClose,
  currentCurrency,
  onSelectCurrency,
}) => {
  const [selectedCode, setSelectedCode] = useState(currentCurrency.code);
  const [customCode, setCustomCode] = useState('');
  const [customSymbol, setCustomSymbol] = useState('');
  const [isCustomMode, setIsCustomMode] = useState(false);

  if (!isOpen) return null;

  const handleSelect = (curr: Currency) => {
    setSelectedCode(curr.code);
    onSelectCurrency(curr);
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customCode.trim() || !customSymbol.trim()) return;

    const newCurr: Currency = {
      code: customCode.trim().toUpperCase(),
      symbol: customSymbol.trim(),
      name: `${customCode.trim().toUpperCase()} (${customSymbol.trim()}) - Custom Currency`,
    };

    onSelectCurrency(newCurr);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Select Currency</h3>
              <p className="text-xs text-[#A0AEC0]">Choose or add your preferred currency</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#13192B] border border-[#2B395B] text-[#A0AEC0] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Currency List */}
        {!isCustomMode ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[50vh] overflow-y-auto pr-1">
              {CURRENCIES.map((curr) => {
                const isSelected = currentCurrency.code === curr.code;
                return (
                  <button
                    key={curr.code}
                    onClick={() => handleSelect(curr)}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all text-left cursor-pointer ${
                      isSelected
                        ? 'bg-[#9D9E54]/20 border-[#9D9E54] text-white shadow-md'
                        : 'bg-[#13192B] border-[#2B395B] text-[#A0AEC0] hover:text-white hover:border-[#3B4D7A]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-[#1D2640] border border-[#2B395B] flex items-center justify-center font-mono font-bold text-white text-sm">
                        {curr.symbol}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">{curr.code}</div>
                        <div className="text-[10px] text-[#A0AEC0]">{curr.name}</div>
                      </div>
                    </div>

                    {isSelected && (
                      <div className="p-1 rounded-full bg-[#9D9E54] text-[#13192B]">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-[#2B395B] flex items-center justify-between">
              <span className="text-xs text-[#A0AEC0]">Currency not listed?</span>
              <button
                type="button"
                onClick={() => setIsCustomMode(true)}
                className="text-xs font-bold text-[#9D9E54] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Currency</span>
              </button>
            </div>
          </div>
        ) : (
          /* Custom Currency Mode */
          <form onSubmit={handleCustomSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#A0AEC0]">Currency Code (e.g. BTC, SGD, SEK)</label>
              <input
                type="text"
                placeholder="e.g. SGD"
                value={customCode}
                onChange={(e) => setCustomCode(e.target.value.toUpperCase())}
                className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white uppercase focus:outline-none focus:border-[#9D9E54]"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#A0AEC0]">Currency Symbol (e.g. $, €, £, kr, ₿)</label>
              <input
                type="text"
                placeholder="e.g. S$"
                value={customSymbol}
                onChange={(e) => setCustomSymbol(e.target.value)}
                className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
                required
              />
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-[#2B395B]">
              <button
                type="button"
                onClick={() => setIsCustomMode(false)}
                className="text-xs text-[#A0AEC0] hover:text-white cursor-pointer"
              >
                Back to List
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                <span>Save Currency</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
