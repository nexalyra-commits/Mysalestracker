import React, { useState } from 'react';
import { Expense, ExpenseCategory, StoreHistory, CategoryBudgets, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import {
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  Scan,
  PlusCircle,
  Store,
  ShoppingCart,
  Wallet,
  SlidersHorizontal,
  Check,
  X,
  Target,
  ShieldCheck,
  AlertCircle,
  PiggyBank,
  Zap,
  Plus,
  Calendar,
  Sparkles,
  BarChart3,
  Repeat,
  Home,
  Utensils,
  Car,
  User,
  Package,
  List,
  LayoutGrid
} from 'lucide-react';
import { INITIAL_CATEGORY_BUDGETS } from '../data/initialData';

interface DashboardViewProps {
  salary: number;
  categoryBudgets: CategoryBudgets;
  expenses: Expense[];
  storeHistory: StoreHistory;
  savingsGoal: number;
  currency: Currency;
  onEditSalary: () => void;
  onUpdateCategoryBudgets: (newBudgets: CategoryBudgets) => void;
  onUpdateSavingsGoal: (newGoal: number) => void;
  onAddExpense: (expenseData: Omit<Expense, 'id'>) => void;
  onNavigate: (tab: any) => void;
}

const CATEGORY_META: Record<ExpenseCategory, { label: string; icon: React.ReactNode; bg: string; fill: string; text: string; border: string }> = {
  groceries: { label: 'Groceries', icon: <ShoppingCart className="w-5 h-5 text-[#9D9E54]" />, bg: 'bg-[#9D9E54]/15', fill: 'bg-[#9D9E54]', text: 'text-[#9D9E54]', border: 'border-[#9D9E54]/30' },
  household: { label: 'Household', icon: <Home className="w-5 h-5 text-indigo-400" />, bg: 'bg-indigo-500/15', fill: 'bg-indigo-500', text: 'text-indigo-400', border: 'border-indigo-500/30' },
  personal: { label: 'Personal', icon: <User className="w-5 h-5 text-rose-400" />, bg: 'bg-rose-500/15', fill: 'bg-rose-500', text: 'text-rose-400', border: 'border-rose-500/30' },
  transport: { label: 'Transport', icon: <Car className="w-5 h-5 text-sky-400" />, bg: 'bg-sky-500/15', fill: 'bg-sky-500', text: 'text-sky-400', border: 'border-sky-500/30' },
  dining: { label: 'Dining', icon: <Utensils className="w-5 h-5 text-amber-400" />, bg: 'bg-amber-500/15', fill: 'bg-amber-500', text: 'text-amber-400', border: 'border-amber-500/30' },
  other: { label: 'Other', icon: <Package className="w-5 h-5 text-slate-300" />, bg: 'bg-slate-500/15', fill: 'bg-slate-400', text: 'text-slate-300', border: 'border-slate-500/30' },
};

export const DashboardView: React.FC<DashboardViewProps> = ({
  salary,
  categoryBudgets,
  expenses,
  storeHistory,
  savingsGoal,
  currency,
  onEditSalary,
  onUpdateCategoryBudgets,
  onUpdateSavingsGoal,
  onAddExpense,
  onNavigate,
}) => {
  const [isEditingCaps, setIsEditingCaps] = useState(false);
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [categoryViewMode, setCategoryViewMode] = useState<'list' | 'grid'>('list');

  const [tempBudgets, setTempBudgets] = useState<CategoryBudgets>(categoryBudgets);
  const [tempGoal, setTempGoal] = useState<number>(savingsGoal);

  // Quick Expense Form State
  const [quickName, setQuickName] = useState('');
  const [quickAmount, setQuickAmount] = useState('');
  const [quickCategory, setQuickCategory] = useState<ExpenseCategory>('dining');
  const [quickStore, setQuickStore] = useState('');
  const [quickDate, setQuickDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [quickIsRecurring, setQuickIsRecurring] = useState(false);
  const [quickRecurringDay, setQuickRecurringDay] = useState(1);

  const totalSpent = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remaining = salary - totalSpent;
  const percentageSpent = salary > 0 ? Math.min(100, (totalSpent / salary) * 100) : 0;
  const currentSaved = Math.max(0, remaining);
  const savingsRate = salary > 0 ? ((currentSaved / salary) * 100).toFixed(1) : '0';

  // Savings Goal calculations & Circular Ring parameters
  const goalRatio = savingsGoal > 0 ? Math.min(1, Math.max(0, currentSaved / savingsGoal)) : 0;
  const goalProgressPct = Math.round(goalRatio * 100);
  const radius = 42;
  const circumference = 2 * Math.PI * radius; // ~263.89
  const strokeDashoffset = circumference - goalRatio * circumference;

  // Category totals
  const categoryTotals: Record<ExpenseCategory, number> = {
    groceries: 0,
    household: 0,
    personal: 0,
    transport: 0,
    dining: 0,
    other: 0,
  };

  expenses.forEach((e) => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
  });

  const totalCategoryCaps = (Object.values(categoryBudgets) as number[]).reduce((a, b) => a + b, 0);

  // Price Hike Notice
  let priceHikeNotice: { item: string; store: string; pct: number } | null = null;
  Object.entries(storeHistory).forEach(([item, stores]) => {
    Object.entries(stores).forEach(([store, records]) => {
      if (records.length >= 2) {
        const first = records[0].price;
        const latest = records[records.length - 1].price;
        if (first > 0) {
          const pct = ((latest - first) / first) * 100;
          if (pct > 5 && (!priceHikeNotice || pct > priceHikeNotice.pct)) {
            priceHikeNotice = { item, store, pct: Math.round(pct * 10) / 10 };
          }
        }
      }
    });
  });

  const handleOpenCapsModal = () => {
    setTempBudgets(categoryBudgets);
    setIsEditingCaps(true);
  };

  const handleSaveCaps = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateCategoryBudgets(tempBudgets);
    setIsEditingCaps(false);
  };

  const handleOpenGoalModal = () => {
    setTempGoal(savingsGoal);
    setIsEditingGoal(true);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSavingsGoal(Math.max(1, tempGoal));
    setIsEditingGoal(false);
  };

  const handleTempBudgetChange = (cat: ExpenseCategory, val: string) => {
    const num = parseFloat(val);
    setTempBudgets((prev) => ({
      ...prev,
      [cat]: isNaN(num) ? 0 : Math.max(0, num),
    }));
  };

  const handleResetDefaults = () => {
    setTempBudgets(INITIAL_CATEGORY_BUDGETS);
  };

  const handleQuickAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(quickAmount);
    if (!quickName.trim() || isNaN(amt) || amt <= 0) return;

    onAddExpense({
      name: quickName.trim(),
      amount: amt,
      category: quickCategory,
      date: quickDate || new Date().toISOString().slice(0, 10),
      store: quickStore.trim() || undefined,
      isRecurring: quickIsRecurring,
      recurringDay: quickIsRecurring ? Math.min(31, Math.max(1, quickRecurringDay)) : undefined,
    });

    // Reset Form
    setQuickName('');
    setQuickAmount('');
    setQuickStore('');
    setQuickIsRecurring(false);
    setIsQuickAddOpen(false);
  };

  const handlePresetPreset = (name: string, amt: number, cat: ExpenseCategory, store: string) => {
    setQuickName(name);
    setQuickAmount(amt.toString());
    setQuickCategory(cat);
    setQuickStore(store);
  };

  return (
    <div className="space-y-6 relative">
      {/* Bento Grid Top Overview Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
        {/* Large Bento Hero Greeting Card */}
        <div className="lg:col-span-6 bg-gradient-to-br from-[#1D2640] via-[#243152] to-[#1D2640] border border-[#2B395B] rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between min-h-[180px] shadow-lg">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full bg-[#9D9E54]/20 border border-[#9D9E54]/40 text-[#9D9E54] text-[10px] font-bold uppercase tracking-widest">
                Nexus Overview
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-light text-white">
              Financial Status:{' '}
              <span className="font-bold text-[#9D9E54]">
                {percentageSpent < 85 ? 'Healthy' : 'Caution'}
              </span>
            </h2>
            <p className="text-[#A0AEC0] text-xs mt-1">
              {expenses.length} transaction{expenses.length !== 1 ? 's' : ''} logged •{' '}
              {savingsRate}% surplus rate
            </p>
          </div>

          <div className="flex items-end justify-between relative z-10 pt-4">
            <div>
              <div className="text-[11px] text-[#A0AEC0] uppercase tracking-wider font-semibold">
                Remaining Monthly Surplus
              </div>
              <div className="text-3xl font-extrabold text-white font-mono mt-0.5">
                {formatCurrency(remaining, currency)}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('summary')}
                className="px-3 py-1.5 rounded-full bg-[#13192B] hover:bg-[#161E33] border border-[#2B395B] text-xs font-semibold text-white transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <BarChart3 className="w-3.5 h-3.5 text-[#9D9E54]" />
                <span>6-Mo Summary</span>
              </button>
              <button
                onClick={onEditSalary}
                className="px-3 py-1.5 rounded-full bg-[#13192B] hover:bg-[#161E33] border border-[#2B395B] text-xs font-semibold text-[#9D9E54] transition-all cursor-pointer"
              >
                Edit Income
              </button>
            </div>
          </div>

          <div className="absolute -right-6 -bottom-6 w-36 h-36 bg-[#9D9E54]/10 rounded-full blur-2xl pointer-events-none" />
        </div>

        {/* Bento Metric 1: Monthly Income & Spent */}
        <div className="lg:col-span-3 bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 flex flex-col justify-between shadow-sm hover:border-[#3B4D7A] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#A0AEC0] uppercase tracking-wider">
              Monthly Income & Spent
            </span>
            <div className="p-2.5 rounded-2xl bg-[#9D9E54]/15 text-[#9D9E54]">
              <Wallet className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 space-y-3">
            <div>
              <span className="text-[10px] text-[#A0AEC0] uppercase font-semibold">Income</span>
              <div className="text-xl font-extrabold text-white font-mono">
                {formatCurrency(salary, currency)}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-[10px] text-[#A0AEC0] uppercase font-semibold">
                <span>Spent</span>
                <span className="font-mono text-rose-400">{formatCurrency(totalSpent, currency)}</span>
              </div>
              <div className="w-full bg-[#13192B] rounded-full h-2 mt-1 overflow-hidden border border-[#253352]">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    percentageSpent > 90 ? 'bg-rose-500' : percentageSpent > 75 ? 'bg-amber-500' : 'bg-[#9D9E54]'
                  }`}
                  style={{ width: `${percentageSpent}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Bento Metric 2: Savings Goal Circular Ring Tracker */}
        <div className="lg:col-span-3 bg-[#1D2640] border border-[#2B395B] rounded-3xl p-5 flex flex-col justify-between shadow-sm hover:border-[#3B4D7A] transition-colors relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#A0AEC0] uppercase tracking-wider">
              Savings Goal
            </span>
            <button
              onClick={handleOpenGoalModal}
              className="p-1.5 rounded-xl bg-[#13192B] hover:bg-[#182138] border border-[#2B395B] text-xs font-bold text-[#9D9E54] transition-all cursor-pointer"
              title="Set Savings Goal"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center justify-around my-2">
            {/* SVG Circular Progress Ring */}
            <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  stroke="#1A233A"
                  strokeWidth="10"
                  fill="transparent"
                />
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  stroke={goalProgressPct >= 100 ? '#10b981' : goalProgressPct >= 70 ? '#9D9E54' : '#f59e0b'}
                  strokeWidth="10"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-700 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                <span className="text-lg font-black text-white font-mono leading-none">
                  {goalProgressPct}%
                </span>
                <span className="text-[9px] text-[#A0AEC0] uppercase font-bold tracking-wider mt-0.5">
                  Goal
                </span>
              </div>
            </div>

            <div className="space-y-1 text-left">
              <div className="text-[10px] text-[#A0AEC0] uppercase font-semibold">Target</div>
              <div className="text-lg font-extrabold text-white font-mono">
                {formatCurrency(savingsGoal, currency, 0)}
              </div>
              <div className="text-[11px] font-semibold text-[#9D9E54] font-mono">
                {formatCurrency(currentSaved, currency, 0)} saved
              </div>
            </div>
          </div>

          <div className="text-[10px] text-[#A0AEC0] flex items-center justify-between border-t border-[#2B395B]/60 pt-2">
            <span>{goalProgressPct >= 100 ? '🎉 Goal Reached!' : `${formatCurrency(Math.max(0, savingsGoal - currentSaved), currency, 0)} to target`}</span>
            <button
              onClick={handleOpenGoalModal}
              className="text-[#9D9E54] hover:underline font-semibold cursor-pointer"
            >
              Adjust
            </button>
          </div>
        </div>
      </div>

      {/* Inflation / Price Alert Banner */}
      {priceHikeNotice && (
        <div className="bg-[#1D2640] border border-amber-500/40 rounded-3xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-200 text-xs shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-amber-300">Inflation Notice: </span>
              <span>
                <strong>{priceHikeNotice.item}</strong> at <strong>{priceHikeNotice.store}</strong> increased by{' '}
                <strong className="text-amber-400 font-mono">{priceHikeNotice.pct}%</strong>.
              </span>
            </div>
          </div>
          <button
            onClick={() => onNavigate('trends')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 font-semibold text-xs transition-all shrink-0 cursor-pointer"
          >
            <span>Analyze Trends</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Quick Action Navigation Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <button
          onClick={() => setIsQuickAddOpen(true)}
          className="flex items-center justify-center gap-2 p-3.5 rounded-3xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-lg shadow-[#9D9E54]/20 transition-all active:scale-95 cursor-pointer"
        >
          <Zap className="w-4 h-4 fill-[#13192B]" />
          <span>Quick Log Expense</span>
        </button>
        <button
          onClick={() => onNavigate('summary')}
          className="flex items-center justify-center gap-2 p-3.5 rounded-3xl bg-[#1D2640] hover:bg-[#253352] border border-[#2B395B] text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <BarChart3 className="w-4 h-4 text-emerald-400" />
          <span>6-Mo Summary</span>
        </button>
        <button
          onClick={() => onNavigate('receipts')}
          className="flex items-center justify-center gap-2 p-3.5 rounded-3xl bg-[#1D2640] hover:bg-[#253352] border border-[#2B395B] text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <Scan className="w-4 h-4 text-[#9D9E54]" />
          <span>Scan Receipt AI</span>
        </button>
        <button
          onClick={() => onNavigate('stores')}
          className="flex items-center justify-center gap-2 p-3.5 rounded-3xl bg-[#1D2640] hover:bg-[#253352] border border-[#2B395B] text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <Store className="w-4 h-4 text-sky-400" />
          <span>Compare Stores</span>
        </button>
        <button
          onClick={() => onNavigate('grocery')}
          className="flex items-center justify-center gap-2 p-3.5 rounded-3xl bg-[#1D2640] hover:bg-[#253352] border border-[#2B395B] text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer col-span-2 sm:col-span-1"
        >
          <ShoppingCart className="w-4 h-4 text-amber-400" />
          <span>Smart Grocery</span>
        </button>
      </div>

      {/* Category Monthly Budget Caps & Spending Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Budget Caps Card */}
        <div className="lg:col-span-7 bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-[#2B395B] pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-white text-sm tracking-tight">
                  Category Monthly Budget Caps
                </h2>
                <p className="text-[11px] text-[#A0AEC0] font-mono mt-0.5">
                  Allocated caps: {formatCurrency(totalCategoryCaps, currency)} / mo
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Category Display View Toggle (List vs Grid) */}
              <div className="flex items-center bg-[#13192B] border border-[#2B395B] rounded-2xl p-1 gap-1">
                <button
                  onClick={() => setCategoryViewMode('list')}
                  className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                    categoryViewMode === 'list'
                      ? 'bg-[#9D9E54] text-[#13192B] shadow-sm'
                      : 'text-[#A0AEC0] hover:text-white'
                  }`}
                  title="List View"
                >
                  <List className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setCategoryViewMode('grid')}
                  className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                    categoryViewMode === 'grid'
                      ? 'bg-[#9D9E54] text-[#13192B] shadow-sm'
                      : 'text-[#A0AEC0] hover:text-white'
                  }`}
                  title="Icon Grid View"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={handleOpenCapsModal}
                className="px-3 py-1.5 rounded-2xl bg-[#13192B] hover:bg-[#182138] border border-[#2B395B] hover:border-[#9D9E54]/50 text-xs font-bold text-[#9D9E54] transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Caps</span>
              </button>
            </div>
          </div>

          {categoryViewMode === 'grid' ? (
            /* Visual Icon Grid View */
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
              {(Object.keys(categoryTotals) as ExpenseCategory[]).map((cat) => {
                const spent = categoryTotals[cat];
                const cap = categoryBudgets[cat] || 1;
                const ratio = spent / cap;
                const pctSpent = Math.round(ratio * 100);
                const isOver = spent > cap;
                const meta = CATEGORY_META[cat];

                return (
                  <div
                    key={cat}
                    onClick={() => onNavigate('expenses')}
                    className="p-4 rounded-2xl bg-[#13192B] border border-[#2B395B] hover:border-[#3B4D7A] transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2.5 rounded-xl bg-[#1D2640] border border-[#2B395B] group-hover:scale-105 transition-transform">
                        {meta.icon}
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase font-mono ${
                        isOver ? 'bg-rose-500/20 text-rose-300' : 'bg-[#9D9E54]/20 text-[#9D9E54]'
                      }`}>
                        {pctSpent}%
                      </span>
                    </div>

                    <div>
                      <div className="text-xs font-bold text-white capitalize">{meta.label}</div>
                      <div className="text-sm font-extrabold text-white font-mono mt-0.5">
                        {formatCurrency(spent, currency)}{' '}
                        <span className="text-[10px] text-[#A0AEC0] font-normal">/ {formatCurrency(cap, currency)}</span>
                      </div>

                      <div className="w-full bg-[#1A233A] rounded-full h-1.5 mt-2 overflow-hidden border border-[#2B395B]">
                        <div
                          className={`h-full rounded-full ${isOver ? 'bg-rose-500' : meta.fill}`}
                          style={{ width: `${Math.min(100, pctSpent)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Detailed Progress List View */
            <div className="space-y-3.5 pt-1">
              {(Object.keys(categoryTotals) as ExpenseCategory[]).map((cat) => {
                const spent = categoryTotals[cat];
                const cap = categoryBudgets[cat] || 1;
                const ratio = spent / cap;
                const pctSpent = Math.round(ratio * 100);
                const remainingCap = cap - spent;
                const isOver = spent > cap;
                const isWarning = !isOver && ratio >= 0.8;
                const meta = CATEGORY_META[cat];

                let barColor = meta.fill;
                if (isOver) {
                  barColor = 'bg-rose-500';
                } else if (isWarning) {
                  barColor = 'bg-amber-500';
                }

                return (
                  <div
                    key={cat}
                    className="p-3.5 rounded-2xl bg-[#13192B]/80 border border-[#2B395B] space-y-2 hover:border-[#3B4D7A] transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase border ${meta.bg} ${meta.text} ${meta.border}`}>
                          {cat}
                        </span>
                        {isOver ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-bold border border-rose-500/30 flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" /> Over Cap
                          </span>
                        ) : isWarning ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-bold border border-amber-500/30">
                            Near Cap
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" /> On Track
                          </span>
                        )}
                      </div>

                      <div className="flex items-baseline gap-1.5 font-mono">
                        <span className="font-extrabold text-white text-xs sm:text-sm">
                          {formatCurrency(spent, currency)}
                        </span>
                        <span className="text-[#A0AEC0] text-xs">
                          / {formatCurrency(cap, currency)}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="w-full bg-[#1A233A] rounded-full h-2.5 overflow-hidden border border-[#2B395B]">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                          style={{ width: `${Math.min(100, Math.max(2, pctSpent))}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[11px] pt-0.5 font-mono">
                        <span className="text-[#A0AEC0] font-medium">
                          {pctSpent}% spent
                        </span>

                        {isOver ? (
                          <span className="text-rose-400 font-bold flex items-center gap-1">
                            Exceeded by {formatCurrency(Math.abs(remainingCap), currency)}
                          </span>
                        ) : (
                          <span className="text-[#9D9E54] font-semibold">
                            {formatCurrency(remainingCap, currency)} remaining
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Transactions Feed Card */}
        <div className="lg:col-span-5 bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
              <h2 className="font-bold text-white text-sm tracking-tight">Recent Transactions</h2>
              <button
                onClick={() => onNavigate('expenses')}
                className="text-xs text-[#9D9E54] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-[#2B395B]/60 mt-2">
              {expenses.length === 0 ? (
                <p className="text-xs text-[#A0AEC0] text-center py-12">No expenses logged yet.</p>
              ) : (
                expenses.slice(0, 5).map((exp) => {
                  const meta = CATEGORY_META[exp.category];
                  return (
                    <div key={exp.id} className="py-3 flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>{exp.name}</span>
                          {exp.isRecurring && (
                            <span className="px-1.5 py-0.5 rounded-full bg-[#9D9E54]/20 text-[#9D9E54] text-[9px] font-extrabold uppercase flex items-center gap-0.5">
                              <Repeat className="w-2.5 h-2.5" /> Day {exp.recurringDay || 1}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-[#A0AEC0]">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${meta.bg} ${meta.text} ${meta.border}`}>
                            {exp.category}
                          </span>
                          {exp.store && <span>· {exp.store}</span>}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-bold text-white font-mono">
                          -{formatCurrency(exp.amount, currency)}
                        </div>
                        <div className="text-[10px] text-[#A0AEC0] font-mono">{exp.date}</div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Action Button (FAB) for Quick Expense Logging */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsQuickAddOpen(true)}
          className="flex items-center gap-2.5 px-5 py-3.5 rounded-full bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-2xl shadow-[#9D9E54]/40 border border-[#B8B96D] transition-all hover:scale-105 active:scale-95 cursor-pointer group"
        >
          <Zap className="w-5 h-5 fill-[#13192B] group-hover:rotate-12 transition-transform" />
          <span className="tracking-tight uppercase">Quick Expense</span>
        </button>
      </div>

      {/* Quick Expense Logging Modal */}
      {isQuickAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
                  <Zap className="w-5 h-5 fill-[#9D9E54]" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Quick Expense Log</h3>
                  <p className="text-xs text-[#A0AEC0]">Record a transaction instantly</p>
                </div>
              </div>
              <button
                onClick={() => setIsQuickAddOpen(false)}
                className="p-1.5 rounded-xl bg-[#13192B] border border-[#2B395B] text-[#A0AEC0] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Preset One-Touch Chips */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-[#A0AEC0] uppercase tracking-wider">
                Quick Presets
              </label>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => handlePresetPreset('Espresso & Pastry', 4.5, 'dining', 'Starbucks')}
                  className="px-2.5 py-1 rounded-xl bg-[#13192B] hover:bg-[#253352] border border-[#2B395B] text-[11px] text-[#9D9E54] font-medium cursor-pointer"
                >
                  ☕ Espresso {formatCurrency(4.5, currency)}
                </button>
                <button
                  type="button"
                  onClick={() => handlePresetPreset('Quick Groceries', 35.0, 'groceries', 'Walmart')}
                  className="px-2.5 py-1 rounded-xl bg-[#13192B] hover:bg-[#253352] border border-[#2B395B] text-[11px] text-[#9D9E54] font-medium cursor-pointer"
                >
                  🛒 Grocery {formatCurrency(35, currency)}
                </button>
                <button
                  type="button"
                  onClick={() => handlePresetPreset('Gasoline Fill', 42.0, 'transport', 'Shell')}
                  className="px-2.5 py-1 rounded-xl bg-[#13192B] hover:bg-[#253352] border border-[#2B395B] text-[11px] text-[#9D9E54] font-medium cursor-pointer"
                >
                  ⛽ Gas {formatCurrency(42, currency)}
                </button>
                <button
                  type="button"
                  onClick={() => handlePresetPreset('Lunch Combo', 14.5, 'dining', 'Chipotle')}
                  className="px-2.5 py-1 rounded-xl bg-[#13192B] hover:bg-[#253352] border border-[#2B395B] text-[11px] text-[#9D9E54] font-medium cursor-pointer"
                >
                  🍕 Lunch {formatCurrency(14.5, currency)}
                </button>
              </div>
            </div>

            <form onSubmit={handleQuickAddSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#A0AEC0]">Expense Title</label>
                <input
                  type="text"
                  placeholder="e.g. Coffee, Taxi, Grocery run"
                  value={quickName}
                  onChange={(e) => setQuickName(e.target.value)}
                  className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#A0AEC0]">Amount ({currency.symbol})</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    value={quickAmount}
                    onChange={(e) => setQuickAmount(e.target.value)}
                    className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#9D9E54]"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#A0AEC0]">Category</label>
                  <select
                    value={quickCategory}
                    onChange={(e) => setQuickCategory(e.target.value as ExpenseCategory)}
                    className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white capitalize focus:outline-none focus:border-[#9D9E54]"
                  >
                    <option value="groceries">Groceries</option>
                    <option value="dining">Dining</option>
                    <option value="household">Household</option>
                    <option value="transport">Transport</option>
                    <option value="personal">Personal</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#A0AEC0]">Store / Merchant</label>
                  <input
                    type="text"
                    placeholder="e.g. Target, Shell"
                    value={quickStore}
                    onChange={(e) => setQuickStore(e.target.value)}
                    className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#A0AEC0]">Date</label>
                  <input
                    type="date"
                    value={quickDate}
                    onChange={(e) => setQuickDate(e.target.value)}
                    className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
                  />
                </div>
              </div>

              {/* Recurring Toggle */}
              <div className="pt-2 border-t border-[#2B395B]/50 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-white select-none">
                  <input
                    type="checkbox"
                    checked={quickIsRecurring}
                    onChange={(e) => setQuickIsRecurring(e.target.checked)}
                    className="w-4 h-4 rounded border-[#2B395B] bg-[#13192B] text-[#9D9E54] focus:ring-0 cursor-pointer accent-[#9D9E54]"
                  />
                  <span className="flex items-center gap-1.5 font-semibold">
                    <Repeat className="w-3.5 h-3.5 text-[#9D9E54]" />
                    <span>Set as Recurring Expense</span>
                  </span>
                </label>

                {quickIsRecurring && (
                  <div className="flex items-center gap-2 animate-fadeIn pl-6">
                    <span className="text-[#A0AEC0] text-[11px]">Repeat on day of month:</span>
                    <input
                      type="number"
                      min="1"
                      max="31"
                      value={quickRecurringDay}
                      onChange={(e) => setQuickRecurringDay(parseInt(e.target.value) || 1)}
                      className="w-16 bg-[#13192B] border border-[#2B395B] rounded-xl px-2 py-1 text-xs text-white text-center font-mono focus:outline-none focus:border-[#9D9E54]"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2B395B]">
                <button
                  type="button"
                  onClick={() => setIsQuickAddOpen(false)}
                  className="px-4 py-2 rounded-2xl bg-[#13192B] border border-[#2B395B] text-xs font-semibold text-[#A0AEC0] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>Log Expense</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Category Budget Caps Modal */}
      {isEditingCaps && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#9D9E54]/20 text-[#9D9E54]">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">
                    Set Monthly Budget Caps
                  </h3>
                  <p className="text-xs text-[#A0AEC0]">
                    Customize spending limits per expense category
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditingCaps(false)}
                className="p-1.5 rounded-xl bg-[#13192B] border border-[#2B395B] text-[#A0AEC0] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCaps} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto pr-1">
                {(Object.keys(tempBudgets) as ExpenseCategory[]).map((cat) => {
                  const meta = CATEGORY_META[cat];
                  return (
                    <div key={cat} className="space-y-1 bg-[#13192B] p-3 rounded-2xl border border-[#2B395B]">
                      <label className="text-xs font-bold text-white capitalize flex items-center justify-between">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${meta.bg} ${meta.text}`}>
                          {cat}
                        </span>
                        <span className="text-[11px] text-[#A0AEC0]">Cap ($)</span>
                      </label>
                      <div className="relative mt-1">
                        <span className="absolute left-3 top-2.5 text-slate-400 text-xs font-mono">$</span>
                        <input
                          type="number"
                          step="10"
                          min="0"
                          value={tempBudgets[cat] || ''}
                          onChange={(e) => handleTempBudgetChange(cat, e.target.value)}
                          className="w-full bg-[#1A233A] border border-[#2B395B] rounded-xl pl-7 pr-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#9D9E54]"
                          required
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-3 rounded-2xl bg-[#13192B] border border-[#2B395B] flex items-center justify-between text-xs">
                <span className="text-[#A0AEC0] font-medium">Total Allocated Budget:</span>
                <span className="font-extrabold font-mono text-[#9D9E54]">
                  ${(Object.values(tempBudgets) as number[]).reduce((a, b) => a + b, 0).toLocaleString()} / mo
                </span>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleResetDefaults}
                  className="text-xs text-[#A0AEC0] hover:text-white underline font-medium cursor-pointer"
                >
                  Reset Defaults
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingCaps(false)}
                    className="px-4 py-2 rounded-2xl bg-[#13192B] border border-[#2B395B] text-xs font-semibold text-[#A0AEC0] cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
                  >
                    <Check className="w-4 h-4 stroke-[2.5]" />
                    <span>Save Caps</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Savings Goal Target Modal */}
      {isEditingGoal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
                  <PiggyBank className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Set Savings Goal</h3>
                  <p className="text-xs text-[#A0AEC0]">Target monthly surplus amount</p>
                </div>
              </div>
              <button
                onClick={() => setIsEditingGoal(false)}
                className="p-1.5 rounded-xl bg-[#13192B] border border-[#2B395B] text-[#A0AEC0] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveGoal} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#A0AEC0]">
                  Target Savings Goal Amount ($)
                </label>
                <div className="relative mt-1">
                  <span className="absolute left-3.5 top-3 text-slate-400 text-sm font-mono">$</span>
                  <input
                    type="number"
                    step="50"
                    min="1"
                    value={tempGoal || ''}
                    onChange={(e) => setTempGoal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#13192B] border border-[#2B395B] rounded-2xl pl-8 pr-3.5 py-2.5 text-sm font-bold text-white font-mono focus:outline-none focus:border-[#9D9E54]"
                    required
                  />
                </div>
              </div>

              <p className="text-[11px] text-[#A0AEC0] leading-relaxed">
                Your remaining monthly surplus (income minus expenditures) will be tracked against this goal on the dashboard.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2B395B]">
                <button
                  type="button"
                  onClick={() => setIsEditingGoal(false)}
                  className="px-4 py-2 rounded-2xl bg-[#13192B] border border-[#2B395B] text-xs font-semibold text-[#A0AEC0] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>Update Goal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
