import React, { useState } from 'react';
import { GroceryItem, StoreHistory, PriceRecord, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import { STORE_COLORS } from '../data/initialData';
import {
  ShoppingCart,
  Plus,
  Check,
  MapPin,
  Sparkles,
  Trash2,
  Tag,
  CheckSquare,
  Square
} from 'lucide-react';

interface SmartGroceryListViewProps {
  groceryList: GroceryItem[];
  storeHistory: StoreHistory;
  currency: Currency;
  onAddGroceryItem: (name: string) => void;
  onToggleGroceryItem: (id: string) => void;
  onDeleteGroceryItem: (id: string) => void;
  onClearChecked: () => void;
}

export const SmartGroceryListView: React.FC<SmartGroceryListViewProps> = ({
  groceryList,
  storeHistory,
  currency,
  onAddGroceryItem,
  onToggleGroceryItem,
  onDeleteGroceryItem,
  onClearChecked,
}) => {
  const [newItemName, setNewItemName] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    onAddGroceryItem(newItemName.trim());
    setNewItemName('');
  };

  // Group grocery items by cheapest store
  const storeGrouped: Record<string, { items: (GroceryItem & { bestPrice: number })[]; storeTotal: number }> = {};
  let unassignedItems: GroceryItem[] = [];

  let overallSmartTotal = 0;
  let singleExpensiveTotal = 0;

  groceryList.forEach((item) => {
    const storesMap = storeHistory[item.name];
    if (storesMap && Object.keys(storesMap).length > 0) {
      let cheapestStore = '';
      let lowestPrice = Infinity;
      let highestPrice = 0;

      Object.entries(storesMap as Record<string, PriceRecord[]>).forEach(([store, records]) => {
        const latestPrice = records[records.length - 1].price;
        if (latestPrice < lowestPrice) {
          lowestPrice = latestPrice;
          cheapestStore = store;
        }
        if (latestPrice > highestPrice) {
          highestPrice = latestPrice;
        }
      });

      if (cheapestStore) {
        if (!storeGrouped[cheapestStore]) {
          storeGrouped[cheapestStore] = { items: [], storeTotal: 0 };
        }
        storeGrouped[cheapestStore].items.push({ ...item, bestPrice: lowestPrice });
        storeGrouped[cheapestStore].storeTotal += lowestPrice;

        overallSmartTotal += lowestPrice;
        singleExpensiveTotal += highestPrice;
      } else {
        unassignedItems.push(item);
      }
    } else {
      unassignedItems.push(item);
    }
  });

  const potentialRouteSavings = Math.max(0, singleExpensiveTotal - overallSmartTotal);

  return (
    <div className="space-y-6">
      {/* Route & Savings Header Bento Card */}
      <div className="bg-gradient-to-r from-[#1D2640] via-[#222E4D] to-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-lg space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <Sparkles className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-white text-sm tracking-tight">
              Smart Store Split Route Optimization
            </h2>
          </div>
          <span className="text-xs font-mono font-bold text-[#9D9E54] px-3 py-1 bg-[#9D9E54]/20 border border-[#9D9E54]/40 rounded-full">
            Estimated Total: {formatCurrency(overallSmartTotal, currency)}
          </span>
        </div>

        <p className="text-xs text-[#A0AEC0] leading-relaxed">
          Splitting your grocery run across <strong className="text-white">{Object.keys(storeGrouped).length} stores</strong> saves you approximately{' '}
          <strong className="text-[#9D9E54] font-mono">{formatCurrency(potentialRouteSavings, currency)}</strong> compared to buying everything at the highest-priced single store.
        </p>

        {/* Route Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {Object.entries(storeGrouped).map(([store, data]) => {
            const color = STORE_COLORS[store] || '#9D9E54';
            return (
              <div
                key={store}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#13192B] border border-[#2B395B] text-xs text-white shadow-sm"
              >
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                <span className="font-bold">{store}</span>
                <span className="text-[#A0AEC0]">({data.items.length} items)</span>
                <span className="font-mono text-[#9D9E54] font-bold">{formatCurrency(data.storeTotal, currency)}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add New Item Input Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-4">
        <form onSubmit={handleAdd} className="flex gap-3">
          <input
            type="text"
            placeholder="Add grocery item (e.g. Organic Milk 1 Gal, Eggs 12ct)..."
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            className="flex-1 bg-[#13192B] border border-[#2B395B] rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54]"
          />
          <button
            type="submit"
            className="px-5 py-2.5 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 shrink-0 active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Item</span>
          </button>
        </form>

        <div className="flex items-center justify-between pt-2 border-t border-[#2B395B] text-xs">
          <span className="text-[#A0AEC0] font-medium">
            {groceryList.filter((i) => i.checked).length} of {groceryList.length} items completed
          </span>
          {groceryList.some((i) => i.checked) && (
            <button
              onClick={onClearChecked}
              className="text-rose-400 hover:text-rose-300 font-semibold hover:underline"
            >
              Clear Checked Items
            </button>
          )}
        </div>
      </div>

      {/* Grouped Lists */}
      <div className="space-y-4">
        {Object.entries(storeGrouped).map(([store, data]) => {
          const storeColor = STORE_COLORS[store] || '#9D9E54';

          return (
            <div
              key={store}
              className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between border-b border-[#2B395B] pb-3.5">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: storeColor }} />
                  <h3 className="font-bold text-white text-sm tracking-tight">
                    Shop at {store}
                  </h3>
                  <span className="text-xs text-[#A0AEC0] font-mono">
                    ({data.items.length} items · {formatCurrency(data.storeTotal, currency)})
                  </span>
                </div>
                <span className="text-xs text-[#9D9E54] font-extrabold uppercase tracking-wider">Best Deals Here</span>
              </div>

              <div className="divide-y divide-[#2B395B]/60">
                {data.items.map((item) => (
                  <div
                    key={item.id}
                    className="py-2.5 flex items-center justify-between group hover:bg-[#161E33] px-3 rounded-2xl transition-colors"
                  >
                    <button
                      onClick={() => onToggleGroceryItem(item.id)}
                      className="flex items-center gap-3 text-left flex-1"
                    >
                      {item.checked ? (
                        <CheckSquare className="w-4 h-4 text-[#9D9E54] shrink-0 stroke-[2.5]" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                      <span
                        className={`text-xs font-bold transition-all ${
                          item.checked
                            ? 'line-through text-slate-500'
                            : 'text-white'
                        }`}
                      >
                        {item.name}
                      </span>
                    </button>

                    <div className="flex items-center gap-4">
                      <span className="font-mono text-xs font-bold text-[#9D9E54]">
                        {formatCurrency(item.bestPrice, currency)}
                      </span>
                      <button
                        onClick={() => onDeleteGroceryItem(item.id)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Unassigned / Untracked Items */}
        {unassignedItems.length > 0 && (
          <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-4">
            <div className="border-b border-[#2B395B] pb-3.5">
              <h3 className="font-bold text-white text-sm tracking-tight">
                Other / Untracked Items ({unassignedItems.length})
              </h3>
              <p className="text-xs text-[#A0AEC0] mt-0.5">
                Scan receipts or log store prices to enable auto store placement
              </p>
            </div>

            <div className="divide-y divide-[#2B395B]/60">
              {unassignedItems.map((item) => (
                <div
                  key={item.id}
                  className="py-2.5 flex items-center justify-between group hover:bg-[#161E33] px-3 rounded-2xl transition-colors"
                >
                  <button
                    onClick={() => onToggleGroceryItem(item.id)}
                    className="flex items-center gap-3 text-left flex-1"
                  >
                    {item.checked ? (
                      <CheckSquare className="w-4 h-4 text-[#9D9E54] shrink-0 stroke-[2.5]" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                    <span
                      className={`text-xs font-bold transition-all ${
                        item.checked
                          ? 'line-through text-slate-500'
                          : 'text-white'
                      }`}
                    >
                      {item.name}
                    </span>
                  </button>

                  <button
                    onClick={() => onDeleteGroceryItem(item.id)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
