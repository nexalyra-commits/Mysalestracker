import React from 'react';
import { StoreHistory, SavingsSuggestion, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import { PiggyBank, ArrowRight, Plus, Sparkles, CheckCircle, TrendingDown } from 'lucide-react';

interface SavingsSuggestionsViewProps {
  storeHistory: StoreHistory;
  currency: Currency;
  onAddGroceryItem: (name: string) => void;
}

export const SavingsSuggestionsView: React.FC<SavingsSuggestionsViewProps> = ({
  storeHistory,
  currency,
  onAddGroceryItem,
}) => {
  const suggestions: SavingsSuggestion[] = [];
  let totalMonthlySavings = 0;

  Object.entries(storeHistory).forEach(([item, stores]) => {
    const storeEntries = Object.entries(stores).map(([s, recs]) => ({
      store: s,
      price: recs[recs.length - 1].price,
    }));

    if (storeEntries.length >= 2) {
      storeEntries.sort((a, b) => a.price - b.price);
      const cheapest = storeEntries[0];
      const expensive = storeEntries[storeEntries.length - 1];

      const diff = expensive.price - cheapest.price;
      if (diff > 0.4) {
        const monthly = diff * 4; // assuming ~4x per month
        totalMonthlySavings += monthly;

        suggestions.push({
          id: 'sug-' + item,
          item,
          currentStore: expensive.store,
          suggestedStore: cheapest.store,
          currentPrice: expensive.price,
          suggestedPrice: cheapest.price,
          monthlySavings: monthly,
          reason: `Switching to ${cheapest.store} saves ${formatCurrency(diff, currency)} per unit (~${formatCurrency(monthly, currency)}/mo).`,
        });
      }
    }
  });

  return (
    <div className="space-y-6">
      {/* Total Potential Savings Hero Bento Card */}
      <div className="bg-gradient-to-r from-[#1D2640] via-[#222E4D] to-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-lg space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2.5 rounded-2xl bg-[#9D9E54]/20 text-[#9D9E54]">
              <PiggyBank className="w-6 h-6 stroke-[2.2]" />
            </div>
            <h2 className="font-bold text-white text-sm tracking-tight">
              AI Smart Savings Recommendations
            </h2>
          </div>
          <span className="px-3.5 py-1.5 rounded-full bg-[#9D9E54]/20 border border-[#9D9E54]/40 text-[#9D9E54] text-xs font-extrabold font-mono shadow-sm">
            Save ~{formatCurrency(totalMonthlySavings, currency, 0)} / month
          </span>
        </div>

        <p className="text-xs text-[#A0AEC0] leading-relaxed">
          Based on your actual scanned receipt prices across local supermarkets, here are personalized store-switching recommendations to reduce your monthly grocery bill.
        </p>
      </div>

      {/* Suggestions List Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#2B395B] pb-4">
          <h3 className="font-bold text-white text-sm tracking-tight">
            Actionable Store Switch Opportunities ({suggestions.length})
          </h3>
        </div>

        <div className="space-y-4">
          {suggestions.length === 0 ? (
            <p className="text-xs text-[#A0AEC0] text-center py-8">
              No store switch recommendations yet. Scan receipts from multiple stores to unlock price comparison insights!
            </p>
          ) : (
            suggestions.map((sug) => (
              <div
                key={sug.id}
                className="bg-[#13192B] border border-[#2B395B] rounded-2xl p-4.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-[#9D9E54]/60 transition-all shadow-sm"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{sug.item}</span>
                    <span className="px-2 py-0.5 rounded-full bg-[#9D9E54]/20 border border-[#9D9E54]/30 text-[#9D9E54] text-[10px] font-extrabold font-mono">
                      Save {formatCurrency(sug.currentPrice - sug.suggestedPrice, currency)} / unit
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-white">
                    <span className="text-[#A0AEC0] line-through">
                      {sug.currentStore} ({formatCurrency(sug.currentPrice, currency)})
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-[#9D9E54] font-bold">
                      {sug.suggestedStore} ({formatCurrency(sug.suggestedPrice, currency)})
                    </span>
                  </div>

                  <p className="text-[11px] text-[#A0AEC0]">{sug.reason}</p>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => onAddGroceryItem(sug.item)}
                    className="px-4 py-2 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs transition-all flex items-center gap-1.5 shadow-md active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Add to Smart List</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
