import React, { useState } from 'react';
import { StoreHistory, PriceRecord, Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import { STORE_COLORS } from '../data/initialData';
import { Store, Search, CheckCircle, TrendingDown, Plus, Tag } from 'lucide-react';

interface StoreCompareViewProps {
  storeHistory: StoreHistory;
  currency: Currency;
  onAddPriceRecord: (item: string, store: string, price: number) => void;
}

export const StoreCompareView: React.FC<StoreCompareViewProps> = ({
  storeHistory,
  currency,
  onAddPriceRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [newItem, setNewItem] = useState('');
  const [newStore, setNewStore] = useState('Walmart');
  const [newPrice, setNewPrice] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const items = Object.keys(storeHistory).filter((it) =>
    it.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Calculate cheapest store overall for all items
  const storeBasketTotals: Record<string, { total: number; count: number }> = {};

  Object.values(storeHistory).forEach((stores) => {
    Object.entries(stores).forEach(([storeName, records]) => {
      const latestPrice = records[records.length - 1].price;
      if (!storeBasketTotals[storeName]) {
        storeBasketTotals[storeName] = { total: 0, count: 0 };
      }
      storeBasketTotals[storeName].total += latestPrice;
      storeBasketTotals[storeName].count += 1;
    });
  });

  const sortedStores = Object.entries(storeBasketTotals).sort(
    (a, b) => a[1].total - b[1].total
  );

  const cheapestStore = sortedStores[0] ? sortedStores[0][0] : 'N/A';
  const cheapestTotal = sortedStores[0] ? sortedStores[0][1].total : 0;
  const expensiveStore = sortedStores[sortedStores.length - 1] ? sortedStores[sortedStores.length - 1][0] : 'N/A';
  const expensiveTotal = sortedStores[sortedStores.length - 1] ? sortedStores[sortedStores.length - 1][1].total : 0;
  const overallSavings = expensiveTotal - cheapestTotal;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parseFloat(newPrice);
    if (!newItem.trim() || isNaN(p) || p <= 0) return;

    onAddPriceRecord(newItem.trim(), newStore, p);
    setNewItem('');
    setNewPrice('');
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Cheapest Store Highlight Bento Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 bg-gradient-to-r from-[#1D2640] via-[#222E4D] to-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-lg space-y-3 relative overflow-hidden">
          <div className="flex items-center gap-2 text-[#9D9E54] font-bold text-xs uppercase tracking-widest">
            <CheckCircle className="w-4 h-4 stroke-[2.5]" />
            <span>Optimal Store Overall</span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-white">{cheapestStore}</span>
            <span className="text-sm font-mono text-[#9D9E54] font-bold">
              {formatCurrency(cheapestTotal, currency)} basket total
            </span>
          </div>
          <p className="text-xs text-[#A0AEC0] leading-relaxed">
            Shopping at <strong className="text-white">{cheapestStore}</strong> saves{' '}
            <strong className="text-[#9D9E54] font-mono">{formatCurrency(overallSavings, currency)}</strong> compared to{' '}
            <strong className="text-white">{expensiveStore}</strong> ({formatCurrency(expensiveTotal, currency)}) for your current tracked basket.
          </p>
        </div>

        <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm flex flex-col justify-between">
          <div className="space-y-1">
            <span className="text-xs font-bold text-[#A0AEC0] uppercase tracking-wider">Total Tracked Items</span>
            <div className="text-3xl font-extrabold text-white font-mono">
              {Object.keys(storeHistory).length}
            </div>
          </div>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="w-full mt-3 py-2.5 px-4 rounded-2xl bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Manual Price</span>
          </button>
        </div>
      </div>

      {/* Manual Price Form */}
      {showAddForm && (
        <div className="bg-[#1D2640] border border-[#9D9E54] rounded-3xl p-6 shadow-xl space-y-4 animate-fadeIn">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#9D9E54]" />
            <span>Log Item Price at Store</span>
          </h3>

          <form onSubmit={handleAddSubmit} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input
              type="text"
              placeholder="Item name (e.g. Milk 1 Gal)"
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              className="bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54]"
              required
            />
            <select
              value={newStore}
              onChange={(e) => setNewStore(e.target.value)}
              className="bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
            >
              {Object.keys(STORE_COLORS).map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <input
              type="number"
              step="0.01"
              placeholder="Price ($)"
              value={newPrice}
              onChange={(e) => setNewPrice(e.target.value)}
              className="bg-[#13192B] border border-[#2B395B] rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#9D9E54] font-mono"
              required
            />
            <button
              type="submit"
              className="bg-[#9D9E54] hover:bg-[#8B8C46] text-[#13192B] font-extrabold text-xs rounded-2xl py-2 px-4 shadow-md transition-all active:scale-95"
            >
              Save Price
            </button>
          </form>
        </div>
      )}

      {/* Compare Matrix List Bento Card */}
      <div className="bg-[#1D2640] border border-[#2B395B] rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-[#2B395B] pb-4">
          <h2 className="font-bold text-white text-sm tracking-tight">Item Price Matrix Across Stores</h2>
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              placeholder="Filter items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#13192B] border border-[#2B395B] rounded-full pl-9 pr-3.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#9D9E54]"
            />
          </div>
        </div>

        <div className="space-y-5 divide-y divide-[#2B395B]/60">
          {items.map((itemName) => {
            const storesMap = storeHistory[itemName];
            const storeEntries = Object.entries(storesMap as Record<string, PriceRecord[]>).map(([s, recs]) => ({
              store: s,
              price: recs[recs.length - 1].price,
              date: recs[recs.length - 1].date,
            }));

            // Find best price
            const minPrice = Math.min(...storeEntries.map((e) => e.price));

            return (
              <div key={itemName} className="pt-4 first:pt-0 space-y-3">
                <div className="font-bold text-sm text-white flex items-center justify-between">
                  <span>{itemName}</span>
                  <span className="text-xs font-normal text-[#A0AEC0]">
                    Best Deal: <strong className="text-[#9D9E54] font-mono font-bold">${minPrice.toFixed(2)}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {storeEntries.map(({ store, price, date }) => {
                    const isBest = price === minPrice;
                    const storeColor = STORE_COLORS[store] || '#9D9E54';

                    return (
                      <div
                        key={store}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          isBest
                            ? 'bg-[#13192B] border-[#9D9E54] shadow-md shadow-[#9D9E54]/10'
                            : 'bg-[#13192B]/80 border-[#2B395B]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full"
                              style={{ backgroundColor: storeColor }}
                            />
                            <span className="text-xs font-bold text-white">{store}</span>
                          </div>
                          {isBest && (
                            <span className="px-2 py-0.5 rounded-full bg-[#9D9E54]/20 text-[#9D9E54] border border-[#9D9E54]/40 text-[10px] font-extrabold uppercase tracking-wider">
                              BEST
                            </span>
                          )}
                        </div>

                        <div className="mt-2.5 flex items-baseline justify-between font-mono">
                          <span
                            className={`text-lg font-extrabold ${
                              isBest ? 'text-[#9D9E54]' : 'text-white'
                            }`}
                          >
                            {formatCurrency(price, currency)}
                          </span>
                          <span className="text-[10px] text-[#A0AEC0]">{date}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
