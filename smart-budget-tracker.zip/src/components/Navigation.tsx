import React from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../data/currencies';
import {
  LayoutDashboard,
  Receipt,
  Scan,
  Store,
  ShoppingCart,
  TrendingUp,
  PiggyBank,
  DollarSign,
  BarChart3,
  Sun,
  Moon,
  Globe
} from 'lucide-react';

export type TabType =
  | 'dashboard'
  | 'expenses'
  | 'summary'
  | 'receipts'
  | 'stores'
  | 'grocery'
  | 'trends'
  | 'suggestions';

interface NavigationProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  unreadAlertsCount?: number;
  salary: number;
  onEditSalary: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  currency: Currency;
  onOpenCurrencyModal: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  unreadAlertsCount = 0,
  salary,
  onEditSalary,
  theme,
  onToggleTheme,
  currency,
  onOpenCurrencyModal,
}) => {
  const tabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'summary', label: 'Monthly Summary', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'expenses', label: 'Expenses', icon: <Receipt className="w-4 h-4" /> },
    { id: 'receipts', label: 'Receipt OCR', icon: <Scan className="w-4 h-4" /> },
    { id: 'stores', label: 'Compare Stores', icon: <Store className="w-4 h-4" /> },
    { id: 'grocery', label: 'Smart List', icon: <ShoppingCart className="w-4 h-4" /> },
    { id: 'trends', label: 'Price Trends', icon: <TrendingUp className="w-4 h-4" />, badge: unreadAlertsCount },
    { id: 'suggestions', label: 'Savings AI', icon: <PiggyBank className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-[#1D2640]/90 backdrop-blur-md border-b border-[#2B395B] sticky top-0 z-30 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 border-b border-[#2B395B]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#9D9E54] flex items-center justify-center text-[#13192B] font-extrabold shadow-md shadow-[#9D9E54]/20">
              <span className="text-xl font-black font-mono">{currency.symbol}</span>
            </div>
            <div>
              <h1 className="font-bold text-lg text-white tracking-tight leading-none flex items-center gap-2">
                NEXUS <span className="text-[#9D9E54] font-light">BUDGET</span>
              </h1>
              <p className="text-[11px] text-[#A0AEC0] mt-0.5">
                Smart Expense Tracking & AI Grocery Intelligence
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Currency Selector Button */}
            <button
              onClick={onOpenCurrencyModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#161E33] hover:bg-[#253352] border border-[#2B395B] text-xs font-bold text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="Change Currency"
            >
              <Globe className="w-3.5 h-3.5 text-[#9D9E54]" />
              <span className="font-mono text-[#9D9E54] font-extrabold">{currency.code} ({currency.symbol})</span>
            </button>

            {/* Theme Switcher */}
            <button
              onClick={onToggleTheme}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#161E33] hover:bg-[#253352] border border-[#2B395B] text-xs font-bold text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title={`Switch to ${theme === 'dark' ? 'Light Mode' : 'Bento Dark'}`}
            >
              {theme === 'dark' ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-[#9D9E54]" />
                  <span className="hidden sm:inline text-[#A0AEC0]">Bento Dark</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  <span className="hidden sm:inline text-slate-700 font-semibold">Light Mode</span>
                </>
              )}
            </button>

            {/* Income Button */}
            <button
              onClick={onEditSalary}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161E33] hover:bg-[#253352] border border-[#2B395B] text-xs font-medium text-white transition-all shadow-sm cursor-pointer"
            >
              <span className="text-[#A0AEC0] hidden sm:inline">Monthly Income:</span>
              <span className="font-bold text-[#9D9E54] font-mono">{formatCurrency(salary, currency)}</span>
            </button>
          </div>
        </div>

        {/* Tab Links */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2.5 no-scrollbar scroll-smooth">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#9D9E54] text-[#13192B] shadow-md shadow-[#9D9E54]/20 scale-[1.02]'
                    : 'text-[#A0AEC0] hover:text-white hover:bg-[#253352]'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.badge && tab.badge > 0 ? (
                  <span className="ml-1 px-1.5 py-0.5 text-[10px] font-extrabold rounded-full bg-[#13192B] text-[#9D9E54]">
                    {tab.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
