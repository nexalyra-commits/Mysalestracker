import { Expense, Receipt, StoreHistory, GroceryItem, CategoryBudgets } from '../types';

export const STORE_COLORS: Record<string, string> = {
  Walmart: '#2563eb', // Blue
  Target: '#dc2626', // Red
  Aldi: '#16a34a', // Green
  'Whole Foods': '#9333ea', // Purple
  Costco: '#ca8a04', // Amber/Yellow
  Kroger: '#0891b2', // Cyan
  "Trader Joe's": '#ea580c', // Orange
};

export const INITIAL_SALARY = 3800;

export const INITIAL_CATEGORY_BUDGETS: CategoryBudgets = {
  groceries: 600,
  household: 1400,
  personal: 200,
  transport: 250,
  dining: 200,
  other: 150,
};

export const INITIAL_EXPENSES: Expense[] = [
  { id: 'exp-1', name: 'Apartment Rent', amount: 1250, category: 'household', date: '2026-08-01', store: 'Management Corp', isRecurring: true, recurringDay: 1, lastAutoLoggedMonth: '2026-08' },
  { id: 'exp-2', name: 'Gasoline Fill-up', amount: 48.50, category: 'transport', date: '2026-08-03', store: 'Shell' },
  { id: 'exp-3', name: 'Morning Espresso & Pastry', amount: 14.25, category: 'dining', date: '2026-08-05', store: 'Local Cafe' },
  { id: 'exp-4', name: 'Gym Membership', amount: 35.00, category: 'personal', date: '2026-08-06', store: 'FitNation', isRecurring: true, recurringDay: 6, lastAutoLoggedMonth: '2026-08' },
];

export const INITIAL_HISTORICAL_RECEIPTS: Receipt[] = [
  {
    id: 'rec-1',
    store: 'Walmart',
    date: '2026-07-05',
    total: 21.56,
    items: [
      { name: 'Milk 1 Gal', price: 3.29, category: 'groceries' },
      { name: 'Whole Wheat Bread', price: 2.79, category: 'groceries' },
      { name: 'Chicken Breast (2 lbs)', price: 6.49, category: 'groceries' },
      { name: 'Toilet Paper 12pk', price: 8.99, category: 'household' },
    ],
  },
  {
    id: 'rec-2',
    store: 'Aldi',
    date: '2026-07-08',
    total: 13.96,
    items: [
      { name: 'Milk 1 Gal', price: 2.79, category: 'groceries' },
      { name: 'Whole Wheat Bread', price: 1.89, category: 'groceries' },
      { name: 'Chicken Breast (2 lbs)', price: 5.99, category: 'groceries' },
      { name: 'Large Eggs 12ct', price: 3.29, category: 'groceries' },
    ],
  },
  {
    id: 'rec-3',
    store: 'Target',
    date: '2026-07-12',
    total: 18.07,
    items: [
      { name: 'Milk 1 Gal', price: 3.59, category: 'groceries' },
      { name: 'Herbal Shampoo', price: 4.99, category: 'household' },
      { name: 'Toilet Paper 12pk', price: 9.49, category: 'household' },
    ],
  },
  {
    id: 'rec-4',
    store: 'Walmart',
    date: '2026-07-20',
    total: 13.07,
    items: [
      { name: 'Milk 1 Gal', price: 3.39, category: 'groceries' },
      { name: 'Large Eggs 12ct', price: 4.19, category: 'groceries' },
      { name: 'Herbal Shampoo', price: 5.49, category: 'household' },
    ],
  },
  {
    id: 'rec-5',
    store: 'Walmart',
    date: '2026-08-02',
    total: 22.96,
    items: [
      { name: 'Milk 1 Gal', price: 3.49, category: 'groceries' },
      { name: 'Whole Wheat Bread', price: 2.99, category: 'groceries' },
      { name: 'Chicken Breast (2 lbs)', price: 6.99, category: 'groceries' },
      { name: 'Toilet Paper 12pk', price: 9.49, category: 'household' },
    ],
  },
  {
    id: 'rec-6',
    store: 'Aldi',
    date: '2026-08-04',
    total: 14.66,
    items: [
      { name: 'Milk 1 Gal', price: 2.89, category: 'groceries' },
      { name: 'Whole Wheat Bread', price: 1.99, category: 'groceries' },
      { name: 'Chicken Breast (2 lbs)', price: 6.29, category: 'groceries' },
      { name: 'Large Eggs 12ct', price: 3.49, category: 'groceries' },
    ],
  },
  {
    id: 'rec-7',
    store: 'Target',
    date: '2026-08-06',
    total: 23.26,
    items: [
      { name: 'Milk 1 Gal', price: 3.79, category: 'groceries' },
      { name: 'Herbal Shampoo', price: 4.49, category: 'household' },
      { name: 'Toilet Paper 12pk', price: 9.99, category: 'household' },
      { name: 'Large Eggs 12ct', price: 4.99, category: 'groceries' },
    ],
  },
  {
    id: 'rec-8',
    store: 'Whole Foods',
    date: '2026-08-07',
    total: 33.45,
    items: [
      { name: 'Milk 1 Gal', price: 4.99, category: 'groceries' },
      { name: 'Whole Wheat Bread', price: 4.49, category: 'groceries' },
      { name: 'Chicken Breast (2 lbs)', price: 8.99, category: 'groceries' },
      { name: 'Large Eggs 12ct', price: 6.99, category: 'groceries' },
      { name: 'Herbal Shampoo', price: 7.99, category: 'household' },
    ],
  },
];

export const INITIAL_GROCERY_LIST: GroceryItem[] = [
  { id: 'g-1', name: 'Milk 1 Gal', checked: false, category: 'groceries' },
  { id: 'g-2', name: 'Whole Wheat Bread', checked: false, category: 'groceries' },
  { id: 'g-3', name: 'Chicken Breast (2 lbs)', checked: false, category: 'groceries' },
  { id: 'g-4', name: 'Large Eggs 12ct', checked: false, category: 'groceries' },
  { id: 'g-5', name: 'Toilet Paper 12pk', checked: false, category: 'household' },
  { id: 'g-6', name: 'Herbal Shampoo', checked: false, category: 'household' },
];

export function buildInitialStoreHistory(receipts: Receipt[]): StoreHistory {
  const history: StoreHistory = {};

  receipts.forEach((receipt) => {
    receipt.items.forEach((item) => {
      if (!history[item.name]) {
        history[item.name] = {};
      }
      if (!history[item.name][receipt.store]) {
        history[item.name][receipt.store] = [];
      }
      history[item.name][receipt.store].push({
        price: item.price,
        date: receipt.date,
      });
      // Sort by date ascending
      history[item.name][receipt.store].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );
    });
  });

  return history;
}
