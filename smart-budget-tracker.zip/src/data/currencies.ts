export interface Currency {
  code: string;
  symbol: string;
  name: string;
}

export const CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'USD ($) - US Dollar' },
  { code: 'EUR', symbol: '€', name: 'EUR (€) - Euro' },
  { code: 'GBP', symbol: '£', name: 'GBP (£) - British Pound' },
  { code: 'JPY', symbol: '¥', name: 'JPY (¥) - Japanese Yen' },
  { code: 'CAD', symbol: 'CA$', name: 'CAD ($) - Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'AUD ($) - Australian Dollar' },
  { code: 'INR', symbol: '₹', name: 'INR (₹) - Indian Rupee' },
  { code: 'CHF', symbol: 'CHF', name: 'CHF (CHF) - Swiss Franc' },
  { code: 'BRL', symbol: 'R$', name: 'BRL (R$) - Brazilian Real' },
  { code: 'MXN', symbol: 'MX$', name: 'MXN ($) - Mexican Peso' },
  { code: 'AED', symbol: 'AED', name: 'AED (AED) - UAE Dirham' },
  { code: 'MUR', symbol: 'Rs', name: 'MUR (Rs) - Mauritian Rupee' },
  { code: 'SGD', symbol: 'S$', name: 'SGD ($) - Singapore Dollar' },
  { code: 'ZAR', symbol: 'R', name: 'ZAR (R) - South African Rand' },
  { code: 'SEK', symbol: 'kr', name: 'SEK (kr) - Swedish Krona' },
  { code: 'NOK', symbol: 'kr', name: 'NOK (kr) - Norwegian Krone' },
  { code: 'DKK', symbol: 'kr', name: 'DKK (kr) - Danish Krone' },
  { code: 'NZD', symbol: 'NZ$', name: 'NZD ($) - New Zealand Dollar' },
  { code: 'PLN', symbol: 'zł', name: 'PLN (zł) - Polish Zloty' },
  { code: 'TRY', symbol: '₺', name: 'TRY (₺) - Turkish Lira' },
];

export const DEFAULT_CURRENCY: Currency = CURRENCIES[0]; // USD ($)

export function formatCurrency(amount: number, currency: Currency | string = '$', decimals: number = 2): string {
  const symbol = typeof currency === 'string' ? currency : (currency?.symbol || '$');
  const formattedAmount = amount.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return `${symbol}${formattedAmount}`;
}
