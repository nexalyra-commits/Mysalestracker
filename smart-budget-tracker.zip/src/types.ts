export type ExpenseCategory = 'groceries' | 'household' | 'personal' | 'transport' | 'dining' | 'other';

export interface Currency {
  code: string;
  symbol: string;
  name: string;
}

export interface Expense {
  id: string;
  name: string;
  amount: number;
  category: ExpenseCategory;
  date: string;
  store?: string;
  note?: string;
  isRecurring?: boolean;
  recurringDay?: number; // 1 - 31 (day of month)
  lastAutoLoggedMonth?: string; // e.g. "2026-08"
}

export interface ReceiptItem {
  name: string;
  price: number;
  quantity?: number;
  category: ExpenseCategory;
}

export interface Receipt {
  id: string;
  store: string;
  date: string;
  items: ReceiptItem[];
  total: number;
  imageUrl?: string;
}

export interface PriceRecord {
  price: number;
  date: string;
}

// storeHistory[itemName][storeName] = PriceRecord[]
export type StoreHistory = Record<string, Record<string, PriceRecord[]>>;

export interface GroceryItem {
  id: string;
  name: string;
  checked: boolean;
  category: ExpenseCategory;
  preferredStore?: string;
}

export interface SavingsSuggestion {
  id: string;
  item: string;
  currentStore: string;
  suggestedStore: string;
  currentPrice: number;
  suggestedPrice: number;
  monthlySavings: number;
  reason: string;
}

export type CategoryBudgets = Record<ExpenseCategory, number>;

export interface ToastNotification {
  id: string;
  type: 'info' | 'warning' | 'danger';
  title?: string;
  message: string;
  category?: ExpenseCategory;
  pct?: number;
}

export interface ReceiptScanResult {
  store: string;
  date: string;
  items: ReceiptItem[];
  total: number;
}
