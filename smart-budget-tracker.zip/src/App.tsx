import React, { useState, useEffect } from 'react';
import {
  TabType,
  Navigation
} from './components/Navigation';
import { DashboardView } from './components/DashboardView';
import { ExpensesView } from './components/ExpensesView';
import { ReceiptsView } from './components/ReceiptsView';
import { StoreCompareView } from './components/StoreCompareView';
import { SmartGroceryListView } from './components/SmartGroceryListView';
import { PriceTrendsView } from './components/PriceTrendsView';
import { SavingsSuggestionsView } from './components/SavingsSuggestionsView';
import { MonthlySummaryView } from './components/MonthlySummaryView';
import { CurrencyModal } from './components/CurrencyModal';
import { AlertTriangle, AlertCircle, CheckCircle2, X } from 'lucide-react';

import {
  Expense,
  Receipt,
  StoreHistory,
  GroceryItem,
  ExpenseCategory,
  ReceiptItem,
  CategoryBudgets,
  ToastNotification,
  Currency
} from './types';
import { DEFAULT_CURRENCY, formatCurrency } from './data/currencies';
import {
  INITIAL_SALARY,
  INITIAL_CATEGORY_BUDGETS,
  INITIAL_EXPENSES,
  INITIAL_HISTORICAL_RECEIPTS,
  INITIAL_GROCERY_LIST,
  buildInitialStoreHistory
} from './data/initialData';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  // Currency State
  const [currency, setCurrency] = useState<Currency>(() => {
    const saved = localStorage.getItem('smart_budget_currency');
    return saved ? JSON.parse(saved) : DEFAULT_CURRENCY;
  });
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('smart_budget_currency', JSON.stringify(currency));
  }, [currency]);

  // Theme State
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('smart_budget_theme');
    return saved === 'light' ? 'light' : 'dark';
  });

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  useEffect(() => {
    localStorage.setItem('smart_budget_theme', theme);
    if (theme === 'light') {
      document.body.classList.add('theme-light');
    } else {
      document.body.classList.remove('theme-light');
    }
  }, [theme]);

  // Salary
  const [salary, setSalary] = useState<number>(() => {
    const saved = localStorage.getItem('smart_budget_salary');
    return saved ? parseFloat(saved) : INITIAL_SALARY;
  });

  // Savings Goal
  const [savingsGoal, setSavingsGoal] = useState<number>(() => {
    const saved = localStorage.getItem('smart_budget_savings_goal');
    return saved ? parseFloat(saved) : 1000;
  });

  // Category Budget Caps
  const [categoryBudgets, setCategoryBudgets] = useState<CategoryBudgets>(() => {
    const saved = localStorage.getItem('smart_budget_category_budgets');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORY_BUDGETS;
  });

  // Expenses
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('smart_budget_expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  // Receipts
  const [receipts, setReceipts] = useState<Receipt[]>(() => {
    const saved = localStorage.getItem('smart_budget_receipts');
    return saved ? JSON.parse(saved) : INITIAL_HISTORICAL_RECEIPTS;
  });

  // Store History
  const [storeHistory, setStoreHistory] = useState<StoreHistory>(() => {
    const saved = localStorage.getItem('smart_budget_store_history');
    if (saved) {
      return JSON.parse(saved);
    }
    return buildInitialStoreHistory(INITIAL_HISTORICAL_RECEIPTS);
  });

  // Grocery List
  const [groceryList, setGroceryList] = useState<GroceryItem[]>(() => {
    const saved = localStorage.getItem('smart_budget_grocery');
    return saved ? JSON.parse(saved) : INITIAL_GROCERY_LIST;
  });

  // Toast Notification System
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const addToast = (notification: Omit<ToastNotification, 'id'> | string) => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const toastObj: ToastNotification =
      typeof notification === 'string'
        ? { id, type: 'info', message: notification }
        : { ...notification, id };

    setToasts((prev) => [toastObj, ...prev].slice(0, 4));

    const timeout = toastObj.type === 'info' ? 3500 : 7000;
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, timeout);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('smart_budget_salary', salary.toString());
  }, [salary]);

  useEffect(() => {
    localStorage.setItem('smart_budget_savings_goal', savingsGoal.toString());
  }, [savingsGoal]);

  useEffect(() => {
    localStorage.setItem('smart_budget_category_budgets', JSON.stringify(categoryBudgets));
  }, [categoryBudgets]);

  useEffect(() => {
    localStorage.setItem('smart_budget_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('smart_budget_receipts', JSON.stringify(receipts));
  }, [receipts]);

  useEffect(() => {
    localStorage.setItem('smart_budget_store_history', JSON.stringify(storeHistory));
  }, [storeHistory]);

  useEffect(() => {
    localStorage.setItem('smart_budget_grocery', JSON.stringify(groceryList));
  }, [groceryList]);

  // Handlers
  const handleEditSalary = () => {
    const val = prompt('Enter monthly salary / income ($):', salary.toString());
    if (val && !isNaN(parseFloat(val))) {
      const newSal = Math.max(0, parseFloat(val));
      setSalary(newSal);
      addToast(`Monthly income updated to $${newSal.toFixed(2)}`);
    }
  };

  const handleUpdateSavingsGoal = (newGoal: number) => {
    setSavingsGoal(newGoal);
    addToast(`Monthly savings target updated to $${newGoal.toLocaleString()}`);
  };

  const handleUpdateCategoryBudgets = (newBudgets: CategoryBudgets) => {
    setCategoryBudgets(newBudgets);

    let hasAlert = false;
    (Object.keys(newBudgets) as ExpenseCategory[]).forEach((cat) => {
      const catSpent = expenses
        .filter((e) => e.category === cat)
        .reduce((sum, e) => sum + e.amount, 0);
      const cap = newBudgets[cat] || 0;
      const ratio = cap > 0 ? catSpent / cap : 0;
      const pct = Math.round(ratio * 100);
      const catLabel = cat.charAt(0).toUpperCase() + cat.slice(1);

      if (ratio >= 1.0) {
        hasAlert = true;
        addToast({
          type: 'danger',
          title: `🚨 100% Budget Limit Reached!`,
          message: `${catLabel} (${formatCurrency(catSpent, currency)}) is at ${pct}% of your new ${formatCurrency(cap, currency)} budget cap!`,
          category: cat,
          pct,
        });
      } else if (ratio >= 0.8) {
        hasAlert = true;
        addToast({
          type: 'warning',
          title: `⚡ 80% Budget Cap Warning`,
          message: `${catLabel} (${formatCurrency(catSpent, currency)}) is at ${pct}% of your new ${formatCurrency(cap, currency)} budget cap.`,
          category: cat,
          pct,
        });
      }
    });

    if (!hasAlert) {
      addToast({
        type: 'info',
        title: 'Budget Caps Saved',
        message: 'Category monthly budget caps updated successfully!',
      });
    }
  };

  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...expenseData,
      id: 'exp-' + Date.now(),
    };
    const updatedExpenses = [...expenses, newExpense];
    setExpenses(updatedExpenses);

    // Check category budget cap
    const cat = newExpense.category;
    const catSpent = updatedExpenses
      .filter((e) => e.category === cat)
      .reduce((sum, e) => sum + e.amount, 0);
    const cap = categoryBudgets[cat] || 0;
    const ratio = cap > 0 ? catSpent / cap : 0;
    const pct = Math.round(ratio * 100);
    const catLabel = cat.charAt(0).toUpperCase() + cat.slice(1);

    if (ratio >= 1.0) {
      addToast({
        type: 'danger',
        title: `🚨 100% Budget Limit Reached!`,
        message: `Added '${newExpense.name}' (${formatCurrency(newExpense.amount, currency)}). ${catLabel} is at ${pct}% (${formatCurrency(catSpent, currency)} / ${formatCurrency(cap, currency)}) of its monthly cap!`,
        category: cat,
        pct,
      });
    } else if (ratio >= 0.8) {
      addToast({
        type: 'warning',
        title: `⚡ 80% Budget Cap Warning`,
        message: `Added '${newExpense.name}' (${formatCurrency(newExpense.amount, currency)}). ${catLabel} is at ${pct}% (${formatCurrency(catSpent, currency)} / ${formatCurrency(cap, currency)}) of its monthly cap.`,
        category: cat,
        pct,
      });
    } else {
      addToast({
        type: 'info',
        title: 'Expense Logged',
        message: `Logged expense: ${newExpense.name} (${formatCurrency(newExpense.amount, currency)})`,
      });
    }
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    addToast('Expense removed.');
  };

  const handleImportReceipt = (receipt: Receipt) => {
    // Add to receipts
    setReceipts((prev) => [receipt, ...prev]);

    // Add items to expenses
    const newExpenses: Expense[] = receipt.items.map((item, idx) => ({
      id: `exp-${receipt.id}-${idx}`,
      name: `${item.name}`,
      amount: item.price,
      category: item.category || 'groceries',
      store: receipt.store,
      date: receipt.date,
    }));

    const updatedExpenses = [...expenses, ...newExpenses];
    setExpenses(updatedExpenses);

    // Update store history
    setStoreHistory((prev) => {
      const updated = { ...prev };
      receipt.items.forEach((item) => {
        if (!updated[item.name]) {
          updated[item.name] = {};
        }
        if (!updated[item.name][receipt.store]) {
          updated[item.name][receipt.store] = [];
        }
        updated[item.name][receipt.store].push({
          price: item.price,
          date: receipt.date,
        });
        updated[item.name][receipt.store].sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
      });
      return updated;
    });

    // Check budget caps for categories present in receipt
    const categoriesInReceipt = Array.from(new Set(newExpenses.map((e) => e.category)));
    let hasAlert = false;

    categoriesInReceipt.forEach((cat) => {
      const catSpent = updatedExpenses
        .filter((e) => e.category === cat)
        .reduce((sum, e) => sum + e.amount, 0);
      const cap = categoryBudgets[cat] || 0;
      const ratio = cap > 0 ? catSpent / cap : 0;
      const pct = Math.round(ratio * 100);
      const catLabel = cat.charAt(0).toUpperCase() + cat.slice(1);

      if (ratio >= 1.0) {
        hasAlert = true;
        addToast({
          type: 'danger',
          title: `🚨 100% Budget Limit Reached!`,
          message: `Imported receipt from ${receipt.store}. ${catLabel} reached ${pct}% ($${catSpent.toFixed(2)} / $${cap.toFixed(2)}) of its limit!`,
          category: cat,
          pct,
        });
      } else if (ratio >= 0.8) {
        hasAlert = true;
        addToast({
          type: 'warning',
          title: `⚡ 80% Budget Cap Warning`,
          message: `Imported receipt from ${receipt.store}. ${catLabel} reached ${pct}% ($${catSpent.toFixed(2)} / $${cap.toFixed(2)}) of its limit.`,
          category: cat,
          pct,
        });
      }
    });

    if (!hasAlert) {
      addToast({
        type: 'info',
        title: 'Receipt Imported',
        message: `Imported receipt from ${receipt.store} ($${receipt.total.toFixed(2)})`,
      });
    }
  };

  const handleAddPriceRecord = (item: string, store: string, price: number) => {
    const today = new Date().toISOString().slice(0, 10);
    setStoreHistory((prev) => {
      const updated = { ...prev };
      if (!updated[item]) updated[item] = {};
      if (!updated[item][store]) updated[item][store] = [];
      updated[item][store].push({ price, date: today });
      updated[item][store].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      return updated;
    });
    addToast(`Recorded price for ${item} at ${store}: $${price.toFixed(2)}`);
  };

  const handleAddGroceryItem = (name: string) => {
    if (groceryList.some((g) => g.name.toLowerCase() === name.toLowerCase())) {
      addToast(`${name} is already in your grocery list.`);
      return;
    }
    const newItem: GroceryItem = {
      id: 'g-' + Date.now(),
      name,
      checked: false,
      category: 'groceries',
    };
    setGroceryList((prev) => [...prev, newItem]);
    addToast(`Added ${name} to grocery list.`);
  };

  const handleToggleGroceryItem = (id: string) => {
    setGroceryList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const handleDeleteGroceryItem = (id: string) => {
    setGroceryList((prev) => prev.filter((i) => i.id !== id));
  };

  const handleClearCheckedGrocery = () => {
    setGroceryList((prev) => prev.filter((i) => !i.checked));
    addToast('Cleared completed items.');
  };

  return (
    <div className="min-h-screen bg-[#13192B] text-white font-sans antialiased selection:bg-[#9D9E54] selection:text-white">
      {/* Toast Notification Alert System Container */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col-reverse gap-3 max-w-sm sm:max-w-md w-full px-4 sm:px-0 pointer-events-none">
        {toasts.map((toast) => {
          const isDanger = toast.type === 'danger';
          const isWarning = toast.type === 'warning';

          return (
            <div
              key={toast.id}
              className={`pointer-events-auto rounded-2xl border p-4 shadow-2xl backdrop-blur-md transition-all duration-300 animate-slideIn flex items-start gap-3.5 ${
                isDanger
                  ? 'bg-[#2A161B]/95 border-rose-500/80 text-rose-100 shadow-rose-950/40'
                  : isWarning
                  ? 'bg-[#2B271A]/95 border-amber-500/80 text-amber-100 shadow-amber-950/40'
                  : 'bg-[#1D2640]/95 border-[#9D9E54] text-white shadow-black/50'
              }`}
            >
              <div
                className={`p-2 rounded-xl shrink-0 ${
                  isDanger
                    ? 'bg-rose-500/20 text-rose-400'
                    : isWarning
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-[#9D9E54]/20 text-[#9D9E54]'
                }`}
              >
                {isDanger ? (
                  <AlertTriangle className="w-5 h-5 stroke-[2.5]" />
                ) : isWarning ? (
                  <AlertCircle className="w-5 h-5 stroke-[2.5]" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                )}
              </div>

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <h4
                    className={`text-xs font-bold tracking-tight ${
                      isDanger
                        ? 'text-rose-300'
                        : isWarning
                        ? 'text-amber-300'
                        : 'text-[#9D9E54]'
                    }`}
                  >
                    {toast.title || (isDanger ? '100% Budget Alert' : isWarning ? '80% Budget Warning' : 'Notification')}
                  </h4>
                  {toast.pct !== undefined && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold font-mono border ${
                        isDanger
                          ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                          : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                      }`}
                    >
                      {toast.pct}%
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-200 leading-relaxed font-normal">
                  {toast.message}
                </p>
              </div>

              <button
                onClick={() => dismissToast(toast.id)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Top Navbar */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        salary={salary}
        onEditSalary={handleEditSalary}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        currency={currency}
        onOpenCurrencyModal={() => setIsCurrencyModalOpen(true)}
      />

      {/* Currency Modal */}
      <CurrencyModal
        isOpen={isCurrencyModalOpen}
        onClose={() => setIsCurrencyModalOpen(false)}
        currentCurrency={currency}
        onSelectCurrency={(newCurr) => {
          setCurrency(newCurr);
          addToast({
            type: 'info',
            title: 'Currency Updated',
            message: `Switched currency to ${newCurr.code} (${newCurr.symbol})`,
          });
        }}
      />

      {/* Main App Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            salary={salary}
            categoryBudgets={categoryBudgets}
            expenses={expenses}
            storeHistory={storeHistory}
            savingsGoal={savingsGoal}
            currency={currency}
            onEditSalary={handleEditSalary}
            onUpdateCategoryBudgets={handleUpdateCategoryBudgets}
            onUpdateSavingsGoal={handleUpdateSavingsGoal}
            onAddExpense={handleAddExpense}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'summary' && (
          <MonthlySummaryView
            salary={salary}
            expenses={expenses}
            categoryBudgets={categoryBudgets}
            savingsGoal={savingsGoal}
            currency={currency}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'expenses' && (
          <ExpensesView
            expenses={expenses}
            currency={currency}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
          />
        )}

        {activeTab === 'receipts' && (
          <ReceiptsView
            receipts={receipts}
            currency={currency}
            onImportReceipt={handleImportReceipt}
          />
        )}

        {activeTab === 'stores' && (
          <StoreCompareView
            storeHistory={storeHistory}
            currency={currency}
            onAddPriceRecord={handleAddPriceRecord}
          />
        )}

        {activeTab === 'grocery' && (
          <SmartGroceryListView
            groceryList={groceryList}
            storeHistory={storeHistory}
            currency={currency}
            onAddGroceryItem={handleAddGroceryItem}
            onToggleGroceryItem={handleToggleGroceryItem}
            onDeleteGroceryItem={handleDeleteGroceryItem}
            onClearChecked={handleClearCheckedGrocery}
          />
        )}

        {activeTab === 'trends' && <PriceTrendsView storeHistory={storeHistory} currency={currency} />}

        {activeTab === 'suggestions' && (
          <SavingsSuggestionsView
            storeHistory={storeHistory}
            currency={currency}
            onAddGroceryItem={handleAddGroceryItem}
          />
        )}
      </main>
    </div>
  );
}
