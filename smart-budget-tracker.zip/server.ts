import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const PORT = 3000;

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '10mb' }));

  // Initialize Gemini Client server-side
  let ai: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Receipt Scanner Endpoint with Gemini Vision / Text AI
  app.post('/api/scan-receipt', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg', textContent } = req.body;

      if (!ai) {
        // Fallback response if GEMINI_API_KEY is not set or mock mode
        return res.json({
          success: true,
          source: 'fallback',
          data: {
            store: 'SuperMarket Plus',
            date: new Date().toISOString().slice(0, 10),
            total: 18.75,
            items: [
              { name: 'Organic Milk 1 Gal', price: 4.29, quantity: 1, category: 'groceries' },
              { name: 'Fresh Artisan Bread', price: 3.49, quantity: 1, category: 'groceries' },
              { name: 'Avocados 4pk', price: 3.99, quantity: 1, category: 'groceries' },
              { name: 'Dish Soap 24oz', price: 6.98, quantity: 1, category: 'household' },
            ],
          },
        });
      }

      let parts: any[] = [];

      if (imageBase64) {
        // Strip data url header if present
        const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
        parts.push({
          inlineData: {
            data: cleanBase64,
            mimeType: mimeType,
          },
        });
        parts.push({
          text: 'Analyze this receipt image. Extract store name, date (YYYY-MM-DD), list of items with their names, total prices, quantity if visible, and assign each item one of these categories: groceries, household, personal, transport, dining, other. Also calculate the total price.',
        });
      } else if (textContent) {
        parts.push({
          text: `Extract structured receipt data from the following text:\n\n${textContent}\n\nReturn store name, date (YYYY-MM-DD), list of item names, prices, quantities, total, and categorize each item as groceries, household, personal, transport, dining, or other.`,
        });
      } else {
        return res.status(400).json({ error: 'Please provide either imageBase64 or textContent' });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: { parts },
        config: {
          systemInstruction:
            'You are an expert receipt OCR analyzer. Extract store name, receipt date (YYYY-MM-DD), items with individual item prices, quantity, and assigned category (groceries, household, personal, transport, dining, other). Return strictly valid JSON.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              store: { type: Type.STRING, description: 'Store name e.g. Walmart, Target, Aldi, Whole Foods' },
              date: { type: Type.STRING, description: 'Date in YYYY-MM-DD format' },
              total: { type: Type.NUMBER, description: 'Total receipt amount' },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: 'Item name' },
                    price: { type: Type.NUMBER, description: 'Price paid for item' },
                    quantity: { type: Type.NUMBER, description: 'Quantity purchased, default 1' },
                    category: { type: Type.STRING, description: 'groceries, household, personal, transport, dining, or other' },
                  },
                  required: ['name', 'price', 'category'],
                },
              },
            },
            required: ['store', 'date', 'total', 'items'],
          },
        },
      });

      const rawText = response.text || '{}';
      const parsedData = JSON.parse(rawText);

      return res.json({
        success: true,
        source: 'gemini',
        data: parsedData,
      });
    } catch (error: any) {
      console.error('Error scanning receipt with Gemini:', error);
      res.status(500).json({ error: error.message || 'Failed to analyze receipt' });
    }
  });

  // Vite development vs production static setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Budget Tracker Server listening at http://localhost:${PORT}`);
  });
}

startServer();
